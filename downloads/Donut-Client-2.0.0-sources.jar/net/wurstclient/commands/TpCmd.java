/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.commands;

import java.util.Comparator;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2828;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.wurstclient.command.CmdError;
import net.wurstclient.command.CmdException;
import net.wurstclient.command.CmdSyntaxError;
import net.wurstclient.command.Command;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.MathUtils;

public final class TpCmd extends Command
{
	private final CheckboxSetting disableFreecam = new CheckboxSetting(
		"Disable Freecam", "Disables Freecam just before teleporting.", false);
	
	public TpCmd()
	{
		super("tp", "Teleports you up to 22 blocks away.", ".tp <x> <y> <z>",
			".tp <entity>");
		addSetting(disableFreecam);
	}
	
	@Override
	public void call(String[] args) throws CmdException
	{
		class_2338 pos = argsToPos(args);
		class_746 player = MC.field_1724;
		
		if(disableFreecam.isChecked() && WURST.getHax().freecamHack.isEnabled())
			WURST.getHax().freecamHack.setEnabled(false);
		
		// Simple teleport at low distances for better stability
		if(player.method_5707(pos.method_61082()) < 100)
		{
			player.method_5814(pos.method_10263(), pos.method_10264(), pos.method_10260());
			return;
		}
		
		// See ServerGamePacketListenerImpl.handleMovePlayer()
		// for why it's using these numbers.
		// Also, let me know if you find a way to bypass that check.
		for(int i = 0; i < 4; i++)
			sendPos(player.method_23317(), player.method_23318(), player.method_23321(), true);
		sendPos(pos.method_10263(), pos.method_10264(), pos.method_10260(), true);
		sendPos(pos.method_10263(), pos.method_10264(), pos.method_10260(), false);
	}
	
	private void sendPos(double x, double y, double z, boolean onGround)
	{
		class_634 netHandler = MC.field_1724.field_3944;
		netHandler.method_52787(new class_2828.class_2829(x, y, z, onGround,
			MC.field_1724.field_5976));
	}
	
	private class_2338 argsToPos(String... args) throws CmdException
	{
		switch(args.length)
		{
			default:
			throw new CmdSyntaxError("Invalid coordinates.");
			
			case 1:
			return argsToEntityPos(args[0]);
			
			case 3:
			return argsToXyzPos(args);
		}
	}
	
	private class_2338 argsToEntityPos(String name) throws CmdError
	{
		class_1309 entity = EntityUtils.getAliveEntities(class_1309.class)
			.filter(EntityUtils.IS_NOT_SELF)
			.filter(e -> name.equalsIgnoreCase(e.method_5476().getString()))
			.min(Comparator.comparingDouble(EntityUtils::distanceToHitboxSq))
			.orElse(null);
		
		if(entity == null)
			throw new CmdError("Entity \"" + name + "\" could not be found.");
		
		return class_2338.method_49638(entity.method_73189());
	}
	
	private class_2338 argsToXyzPos(String... xyz) throws CmdSyntaxError
	{
		class_2338 playerPos = class_2338.method_49638(MC.field_1724.method_73189());
		int[] player = {playerPos.method_10263(), playerPos.method_10264(), playerPos.method_10260()};
		int[] pos = new int[3];
		
		for(int i = 0; i < 3; i++)
			if(MathUtils.isInteger(xyz[i]))
				pos[i] = Integer.parseInt(xyz[i]);
			else if(xyz[i].equals("~"))
				pos[i] = player[i];
			else if(xyz[i].startsWith("~")
				&& MathUtils.isInteger(xyz[i].substring(1)))
				pos[i] = player[i] + Integer.parseInt(xyz[i].substring(1));
			else
				throw new CmdSyntaxError("Invalid coordinates.");
			
		return new class_2338(pos[0], pos[1], pos[2]);
	}
}
