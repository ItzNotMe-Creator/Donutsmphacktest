/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hud;

import net.minecraft.class_332;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.screens.ClickGuiScreen;
import net.wurstclient.events.GUIRenderListener;

public final class IngameHUD implements GUIRenderListener
{
	private final WurstLogo wurstLogo = new WurstLogo();
	private final HackListHUD hackList = new HackListHUD();
	private TabGui tabGui;
	
	@Override
	public void onRenderGUI(class_332 graphics, float partialTicks)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		if(tabGui == null)
			tabGui = new TabGui();
		
		ClickGui clickGui = WurstClient.INSTANCE.getGui();
		
		clickGui.updateColors();
		
		wurstLogo.render(graphics);
		hackList.render(graphics, partialTicks);
		tabGui.render(graphics, partialTicks);
		
		// pinned windows
		if(!(WurstClient.MC.field_1755 instanceof ClickGuiScreen))
			clickGui.renderPinnedWindows(graphics, partialTicks);
	}
	
	public HackListHUD getHackList()
	{
		return hackList;
	}
}
