/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import net.minecraft.class_10799;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public enum WurstShaderPipelines
{
	;
	
	/**
	 * Similar to the RENDERTYPE_LINES Snippet, but without fog.
	 */
	public static final Snippet FOGLESS_LINES_SNIPPET = RenderPipeline
		.builder(class_10799.field_60127,
			class_10799.field_60126)
		.withVertexShader(class_2960.method_60654("wurst:core/fogless_lines"))
		.withFragmentShader(class_2960.method_60654("wurst:core/fogless_lines"))
		.withBlend(BlendFunction.TRANSLUCENT).withCull(false)
		.withVertexFormat(class_290.field_63455,
			class_5596.field_27377)
		.buildSnippet();
	
	/**
	 * Similar to the LINES ShaderPipeline, but with no fog.
	 */
	public static final RenderPipeline DEPTH_TEST_LINES =
		class_10799.method_67887(RenderPipeline.builder(FOGLESS_LINES_SNIPPET)
			.withLocation(
				class_2960.method_60654("wurst:pipeline/wurst_depth_test_lines"))
			.build());
	
	/**
	 * Similar to the LINES ShaderPipeline, but with no depth test or fog.
	 */
	public static final RenderPipeline ESP_LINES =
		class_10799.method_67887(RenderPipeline.builder(FOGLESS_LINES_SNIPPET)
			.withLocation(class_2960.method_60654("wurst:pipeline/wurst_esp_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with culling enabled.
	 */
	public static final RenderPipeline QUADS = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation(class_2960.method_60654("wurst:pipeline/wurst_quads"))
			.withCull(true)
			.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
			.build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with culling enabled
	 * and no depth test.
	 */
	public static final RenderPipeline ESP_QUADS = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation(class_2960.method_60654("wurst:pipeline/wurst_esp_quads"))
			.withCull(true)
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with no depth test.
	 */
	public static final RenderPipeline ESP_QUADS_NO_CULLING = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation(class_2960.method_60654("wurst:pipeline/wurst_esp_quads"))
			.withCull(false)
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
}
