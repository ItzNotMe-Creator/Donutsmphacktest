/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.GUIRenderListener.GUIRenderEvent;

@Mixin(class_329.class)
public class GuiMixin
{
	/**
	 * Fires GUIRenderEvent after the scoreboard and before the tab list is
	 * rendered.
	 */
	@Inject(
		method = "renderTabList(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V",
		at = @At("HEAD"))
	private void onRenderTabList(class_332 graphics, class_9779 tickCounter,
		CallbackInfo ci)
	{
		if(WurstClient.MC.field_61504.method_72776())
			return;
		
		float tickDelta = tickCounter.method_60637(true);
		EventManager.fire(new GUIRenderEvent(graphics, tickDelta));
	}
}
