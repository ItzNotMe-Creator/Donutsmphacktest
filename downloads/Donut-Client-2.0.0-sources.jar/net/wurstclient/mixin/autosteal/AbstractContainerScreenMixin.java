/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.autosteal;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_495;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.AutoStealHack;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin extends class_437
{
	@Shadow
	protected int imageWidth;
	@Shadow
	protected int leftPos;
	@Shadow
	protected int topPos;
	
	private AbstractContainerScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(method = "init()V", at = @At("TAIL"))
	private void onInit(CallbackInfo ci)
	{
		class_465<?> screen =
			(class_465<?>)(Object)this;
		int rows;
		if(screen instanceof class_476 chest)
			rows = chest.method_17577().method_17388();
		else if(screen instanceof class_495)
			rows = 3;
		else
			return;
		
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		AutoStealHack autoSteal = WurstClient.INSTANCE.getHax().autoStealHack;
		if(autoSteal.areButtonsVisible())
		{
			method_37063(class_4185
				.method_46430(class_2561.method_43470("Steal"),
					b -> autoSteal.steal(screen, rows))
				.method_46434(leftPos + imageWidth - 108, topPos + 4, 50, 12)
				.method_46431());
			
			method_37063(class_4185
				.method_46430(class_2561.method_43470("Store"),
					b -> autoSteal.store(screen, rows))
				.method_46434(leftPos + imageWidth - 56, topPos + 4, 50, 12).method_46431());
		}
		
		if(autoSteal.isEnabled())
			autoSteal.steal(screen, rows);
	}
}
