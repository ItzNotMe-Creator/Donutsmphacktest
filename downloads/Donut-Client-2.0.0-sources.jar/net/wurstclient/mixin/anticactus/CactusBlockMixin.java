/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.anticactus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.wurstclient.WurstClient;
import net.wurstclient.hack.HackList;

@Mixin(class_2266.class)
public abstract class CactusBlockMixin extends class_2248
{
	private CactusBlockMixin(WurstClient wurst, class_2251 settings)
	{
		super(settings);
	}
	
	@Inject(
		method = "getCollisionShape(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetCollisionShape(class_2680 state, class_1922 level,
		class_2338 pos, class_3726 context,
		CallbackInfoReturnable<class_265> cir)
	{
		if(level instanceof class_3218)
			return;
		
		HackList hax = WurstClient.INSTANCE.getHax();
		if(hax != null && hax.antiCactusHack.isEnabled())
			cir.setReturnValue(hax.antiCactusHack.getCollisionShape());
	}
}
