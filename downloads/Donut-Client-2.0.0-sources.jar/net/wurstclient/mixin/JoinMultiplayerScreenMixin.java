/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;
import net.minecraft.class_8667;
import net.wurstclient.WurstClient;
import net.wurstclient.serverfinder.CleanUpScreen;
import net.wurstclient.serverfinder.ServerFinderScreen;
import net.wurstclient.util.LastServerRememberer;

@Mixin(class_500.class)
public class JoinMultiplayerScreenMixin extends class_437
{
	private class_4185 lastServerButton;
	
	private JoinMultiplayerScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(method = "init()V", at = @At("HEAD"))
	private void beforeVanillaButtons(CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		class_500 mpScreen = (class_500)(Object)this;
		
		// Add Last Server button early for better tab navigation
		lastServerButton = class_4185
			.method_46430(class_2561.method_30163("Last Server"),
				b -> LastServerRememberer.joinLastServer(mpScreen))
			.method_46432(100).method_46431();
		method_37063(lastServerButton);
	}
	
	@Inject(method = "init()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/gui/screens/multiplayer/JoinMultiplayerScreen;repositionElements()V",
			ordinal = 0))
	private void afterVanillaButtons(CallbackInfo ci,
		@Local(ordinal = 1) class_8667 footerTopRow,
		@Local(ordinal = 2) class_8667 footerBottomRow)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		class_500 mpScreen = (class_500)(Object)this;
		
		class_4185 serverFinderButton = class_4185
			.method_46430(class_2561.method_30163("Server Finder"),
				b -> field_22787.method_1507(new ServerFinderScreen(mpScreen)))
			.method_46432(100).method_46431();
		method_37063(serverFinderButton);
		footerTopRow.method_52736(serverFinderButton);
		
		class_4185 cleanUpButton = class_4185
			.method_46430(class_2561.method_30163("Clean Up"),
				b -> field_22787.method_1507(new CleanUpScreen(mpScreen)))
			.method_46432(100).method_46431();
		method_37063(cleanUpButton);
		footerBottomRow.method_52736(cleanUpButton);
	}
	
	@Inject(method = "repositionElements()V", at = @At("TAIL"))
	private void onRepositionElements(CallbackInfo ci)
	{
		updateLastServerButton();
	}
	
	@Inject(method = "join(Lnet/minecraft/client/multiplayer/ServerData;)V",
		at = @At("HEAD"))
	private void onJoin(class_642 entry, CallbackInfo ci)
	{
		LastServerRememberer.setLastServer(entry);
		updateLastServerButton();
	}
	
	@Unique
	private void updateLastServerButton()
	{
		if(lastServerButton == null)
			return;
		
		lastServerButton.field_22763 = LastServerRememberer.getLastServer() != null;
		lastServerButton.method_46421(field_22789 / 2 - 154);
		lastServerButton.method_46419(6);
	}
}
