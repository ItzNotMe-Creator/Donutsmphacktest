/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.noshieldoverlay;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.wurstclient.WurstClient;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin
{
	/**
	 * Lowers the shield (including custom shield items from datapacks) when
	 * blocking if NoShieldOverlay is enabled.
	 */
	@Inject(
		method = "renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;I)V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;getUseAnimation()Lnet/minecraft/world/item/ItemUseAnimation;",
			shift = At.Shift.AFTER))
	private void onRenderArmWithItemBlocking(class_742 player,
		float tickProgress, float pitch, class_1268 hand,
		float swingProgress, class_1799 item, float equipProgress,
		class_4587 matrices, class_11659 entityRenderCommandQueue,
		int light, CallbackInfo ci)
	{
		// Check if item has block animation component
		if(item.method_7976() != class_1839.field_8949)
			return;
		
		// Lower the shield
		WurstClient.INSTANCE.getHax().noShieldOverlayHack
			.adjustShieldPosition(matrices, true);
	}
	
	/**
	 * Lowers the shield (including custom shield items from datapacks) when
	 * NOT blocking if NoShieldOverlay is enabled.
	 */
	@Inject(
		method = "renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;I)V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;getSwingAnimation()Lnet/minecraft/world/item/component/SwingAnimation;"))
	private void onRenderArmWithItemNotBlocking(class_742 player,
		float tickProgress, float pitch, class_1268 hand,
		float swingProgress, class_1799 item, float equipProgress,
		class_4587 matrices, class_11659 entityRenderCommandQueue,
		int light, CallbackInfo ci)
	{
		// Check if item has block animation component
		if(item.method_7976() != class_1839.field_8949)
			return;
		
		// Lower the shield
		WurstClient.INSTANCE.getHax().noShieldOverlayHack
			.adjustShieldPosition(matrices, false);
	}
}
