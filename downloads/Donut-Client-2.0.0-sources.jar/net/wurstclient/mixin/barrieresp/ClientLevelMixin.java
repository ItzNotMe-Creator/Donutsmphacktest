/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.barrieresp;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.wurstclient.WurstClient;

@Mixin(class_638.class)
public class ClientLevelMixin
{
	@Shadow
	@Final
	private class_310 minecraft;
	
	/**
	 * This is the part that makes BarrierESP work.
	 */
	@Inject(
		method = "getMarkerParticleTarget()Lnet/minecraft/world/level/block/Block;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetMarkerParticleTarget(CallbackInfoReturnable<class_2248> cir)
	{
		if(!WurstClient.INSTANCE.getHax().barrierEspHack.isEnabled())
			return;
			
		// Pause BarrierESP when holding a light in Creative Mode, since it
		// would otherwise prevent the player from seeing light blocks.
		if(minecraft.field_1761.method_2920() == class_1934.field_9220
			&& minecraft.field_1724.method_6047().method_7909() == class_1802.field_30904)
			return;
		
		cir.setReturnValue(class_2246.field_10499);
	}
}
