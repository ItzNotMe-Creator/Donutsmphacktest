/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import java.io.File;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_3678;
import net.minecraft.class_3966;
import net.minecraft.class_4093;
import net.minecraft.class_542;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.class_7853;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.HandleBlockBreakingListener.HandleBlockBreakingEvent;
import net.wurstclient.events.HandleInputListener.HandleInputEvent;
import net.wurstclient.events.LeftClickListener.LeftClickEvent;
import net.wurstclient.events.RightClickListener.RightClickEvent;
import net.wurstclient.mixinterface.ILocalPlayer;
import net.wurstclient.mixinterface.IMinecraft;
import net.wurstclient.mixinterface.IMultiPlayerGameMode;

@Mixin(class_310.class)
public abstract class MinecraftMixin
	extends class_4093<Runnable>
	implements class_3678, IMinecraft
{
	@Shadow
	@Final
	public File gameDirectory;
	@Shadow
	public class_636 gameMode;
	@Shadow
	public class_746 player;
	
	@Unique
	private YggdrasilAuthenticationService wurstAuthenticationService;
	
	private class_320 wurstUser;
	private class_7853 wurstProfileKeys;
	
	private MinecraftMixin(WurstClient wurst, String name)
	{
		super(name);
	}
	
	@Inject(method = "<init>",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/server/Services;create(Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;Ljava/io/File;)Lnet/minecraft/server/Services;",
			shift = At.Shift.AFTER))
	private void captureAuthenticationService(class_542 args, CallbackInfo ci,
		@Local YggdrasilAuthenticationService yggdrasilAuthenticationService)
	{
		wurstAuthenticationService = yggdrasilAuthenticationService;
	}
	
	/**
	 * Runs just before {@link class_310#method_1508()}, bypassing
	 * the <code>overlay == null && currentScreen == null</code> check in
	 * {@link class_310#method_1574()}.
	 */
	@Inject(method = "tick()V",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/Minecraft;overlay:Lnet/minecraft/client/gui/screens/Overlay;",
			ordinal = 0))
	private void onHandleKeybinds(CallbackInfo ci)
	{
		// Make sure this event is not fired outside of gameplay
		if(player == null)
			return;
		
		EventManager.fire(HandleInputEvent.INSTANCE);
	}
	
	@Inject(method = "startAttack()Z",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/Minecraft;hitResult:Lnet/minecraft/world/phys/HitResult;",
			ordinal = 0),
		cancellable = true)
	private void onStartAttack(CallbackInfoReturnable<Boolean> cir)
	{
		LeftClickEvent event = new LeftClickEvent();
		EventManager.fire(event);
		
		if(event.isCancelled())
			cir.setReturnValue(false);
	}
	
	@Inject(method = "startUseItem()V",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/Minecraft;rightClickDelay:I",
			ordinal = 0),
		cancellable = true)
	private void onStartUseItem(CallbackInfo ci)
	{
		RightClickEvent event = new RightClickEvent();
		EventManager.fire(event);
		
		if(event.isCancelled())
			ci.cancel();
	}
	
	@Inject(method = "pickBlock()V", at = @At("HEAD"))
	private void onPickBlock(CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		if(!(WurstClient.MC.field_1765 instanceof class_3966 hit))
			return;
		
		WurstClient.INSTANCE.getFriends().middleClick(hit.method_17782());
	}
	
	/**
	 * Allows hacks to cancel vanilla block breaking and replace it with their
	 * own. Useful for Nuker-like hacks.
	 */
	@Inject(method = "continueAttack(Z)V", at = @At("HEAD"), cancellable = true)
	private void onContinueAttack(boolean breaking, CallbackInfo ci)
	{
		HandleBlockBreakingEvent event = new HandleBlockBreakingEvent();
		EventManager.fire(event);
		
		if(event.isCancelled())
			ci.cancel();
	}
	
	@Inject(method = "getUser()Lnet/minecraft/client/User;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetUser(CallbackInfoReturnable<class_320> cir)
	{
		if(wurstUser != null)
			cir.setReturnValue(wurstUser);
	}
	
	@Inject(method = "getGameProfile()Lcom/mojang/authlib/GameProfile;",
		at = @At("RETURN"),
		cancellable = true)
	public void onGetGameProfile(CallbackInfoReturnable<GameProfile> cir)
	{
		if(wurstUser == null)
			return;
		
		GameProfile oldProfile = cir.getReturnValue();
		GameProfile newProfile = new GameProfile(wurstUser.method_44717(),
			wurstUser.method_1676(), oldProfile.properties());
		cir.setReturnValue(newProfile);
	}
	
	@Inject(
		method = "getProfileKeyPairManager()Lnet/minecraft/client/multiplayer/ProfileKeyPairManager;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetProfileKeyPairManager(
		CallbackInfoReturnable<class_7853> cir)
	{
		if(WurstClient.INSTANCE.getOtfs().noChatReportsOtf.isActive())
			cir.setReturnValue(class_7853.field_40800);
		
		if(wurstProfileKeys == null)
			return;
		
		cir.setReturnValue(wurstProfileKeys);
	}
	
	@Override
	public ILocalPlayer getPlayer()
	{
		return (ILocalPlayer)player;
	}
	
	@Override
	public IMultiPlayerGameMode getGameMode()
	{
		return (IMultiPlayerGameMode)gameMode;
	}
	
	@Override
	public class_320 getWurstUser()
	{
		return wurstUser;
	}
	
	@Override
	public void setWurstUser(class_320 user)
	{
		wurstUser = user;
		if(user == null)
		{
			wurstProfileKeys = null;
			return;
		}
		
		String accessToken = user.method_1674();
		boolean isOffline = accessToken == null || accessToken.isBlank()
			|| accessToken.equals("0") || accessToken.equals("null");
		UserApiService userApiService = isOffline ? UserApiService.OFFLINE
			: wurstAuthenticationService.createUserApiService(accessToken);
		wurstProfileKeys = class_7853.method_46532(userApiService, user,
			gameDirectory.toPath());
	}
}
