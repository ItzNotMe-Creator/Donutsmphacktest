/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.nobackground;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_332;
import net.minecraft.class_362;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;

@Mixin(class_437.class)
public abstract class ScreenMixin extends class_362
	implements class_4068
{
	@Inject(
		method = "renderTransparentBackground(Lnet/minecraft/client/gui/GuiGraphics;)V",
		at = @At("HEAD"),
		cancellable = true)
	public void onRenderTransparentBackground(class_332 graphics,
		CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().noBackgroundHack
			.shouldCancelBackground((class_437)(Object)this))
			ci.cancel();
	}
	
	@Inject(
		method = "renderBlurredBackground(Lnet/minecraft/client/gui/GuiGraphics;)V",
		at = @At("HEAD"),
		cancellable = true)
	public void onRenderBlurredBackground(class_332 graphics, CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().noBackgroundHack
			.shouldCancelBackground((class_437)(Object)this))
			ci.cancel();
	}
	
	@Inject(
		method = "renderMenuBackground(Lnet/minecraft/client/gui/GuiGraphics;IIII)V",
		at = @At("HEAD"),
		cancellable = true)
	public void onRenderMenuBackground(class_332 graphics, int x, int y,
		int width, int height, CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().noBackgroundHack
			.shouldCancelBackground((class_437)(Object)this))
			ci.cancel();
	}
}
