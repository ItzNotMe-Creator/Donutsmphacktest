/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.autorespawn;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_418;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.AutoRespawnHack;

@Mixin(class_418.class)
public abstract class DeathScreenMixin extends class_437
{
	private DeathScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(method = "tick()V", at = @At("TAIL"))
	private void onTick(CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().autoRespawnHack.isEnabled())
			respawn();
	}
	
	@Inject(method = "init()V", at = @At("TAIL"))
	private void onInit(CallbackInfo ci)
	{
		AutoRespawnHack autoRespawn =
			WurstClient.INSTANCE.getHax().autoRespawnHack;
		
		if(!autoRespawn.shouldShowButton())
			return;
		
		int backButtonX = field_22789 / 2 - 100;
		int backButtonY = field_22790 / 4;
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("AutoRespawn: OFF"), b -> {
				autoRespawn.setEnabled(true);
				respawn();
			}).method_46434(backButtonX, backButtonY + 48, 200, 20).method_46431());
	}
	
	@Unique
	private void respawn()
	{
		field_22787.field_1724.method_7331();
		field_22787.method_1507(null);
	}
}
