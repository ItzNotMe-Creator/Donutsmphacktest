/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_2561;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ChatOutputListener.ChatOutputEvent;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437
{
	private ChatScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(method = "handleChatInput(Ljava/lang/String;Z)V",
		at = @At(value = "INVOKE",
			target = "Ljava/lang/String;isEmpty()Z",
			shift = At.Shift.AFTER),
		cancellable = true)
	private void onHandleChatInput(String messageDontUse, boolean addToHistory,
		CallbackInfo ci, @Local(argsOnly = true) LocalRef<String> message)
	{
		if(message.get().isEmpty())
			return;
		
		ChatOutputEvent event = new ChatOutputEvent(message.get());
		EventManager.fire(event);
		
		if(event.isCancelled())
		{
			// Preserve history even for cancelled messages
			// Otherwise the up/down arrows won't work correctly
			if(addToHistory)
				field_22787.field_1705.method_1743().method_1803(event.getMessage());
			
			ci.cancel();
			return;
		}
		
		message.set(event.getMessage());
	}
}
