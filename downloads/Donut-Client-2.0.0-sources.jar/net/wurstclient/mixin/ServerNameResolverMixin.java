/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import java.util.Optional;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_6368;
import net.minecraft.class_6369;
import net.minecraft.class_6370;
import net.minecraft.class_6371;
import net.minecraft.class_639;
import net.wurstclient.WurstClient;

@Mixin(class_6370.class)
public class ServerNameResolverMixin
{
	@Shadow
	@Final
	private class_6369 resolver;
	
	@Shadow
	@Final
	private class_6371 redirectHandler;
	
	/**
	 * This mixin allows users to connect to servers that have been shadowbanned
	 * by Mojang, such as CS:GO and GTA clones that are apparently "too
	 * adult-oriented" for having pixelated guns.
	 */
	@Inject(
		method = "resolveAddress(Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)Ljava/util/Optional;",
		at = @At("HEAD"),
		cancellable = true)
	public void onResolveAddress(class_639 address,
		CallbackInfoReturnable<Optional<class_6368>> cir)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		Optional<class_6368> optionalAddress =
			resolver.resolve(address);
		Optional<class_639> optionalRedirect =
			redirectHandler.lookupRedirect(address);
		
		if(optionalRedirect.isPresent())
			optionalAddress = resolver.resolve(optionalRedirect.get());
		
		cir.setReturnValue(optionalAddress);
	}
}
