/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.nofog;

import org.joml.Vector4f;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import net.wurstclient.WurstClient;

@Mixin(class_758.class)
public class FogRendererMixin
{
	/**
	 * Removes the fog near the end of the render distance in all dimensions,
	 * if NoFog is enabled.
	 *
	 * <p>
	 * Injected before RETURN so that Sodium's FogRendererMixin doesn't ignore
	 * it.
	 */
	@Inject(
		method = "setupFog(Lnet/minecraft/client/Camera;ILnet/minecraft/client/DeltaTracker;FLnet/minecraft/client/multiplayer/ClientLevel;)Lorg/joml/Vector4f;",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/renderer/fog/FogData;renderDistanceEnd:F",
			opcode = Opcodes.PUTFIELD,
			shift = At.Shift.AFTER))
	private void modifyFogData(class_4184 camera, int renderDistanceInChunks,
		class_9779 deltaTracker, float darkenWorldAmount, class_638 level,
		CallbackInfoReturnable<Vector4f> cir, @Local class_7285 fog)
	{
		if(!WurstClient.INSTANCE.getHax().noFogHack.isEnabled())
			return;
		
		fog.field_60583 = 1000000;
		fog.field_60585 = 1000000;
	}
}
