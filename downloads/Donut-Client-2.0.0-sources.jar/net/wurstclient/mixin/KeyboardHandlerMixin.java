/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.KeyPressListener.KeyPressEvent;

@Mixin(class_309.class)
public class KeyboardHandlerMixin
{
	@Inject(method = "keyPress(JILnet/minecraft/client/input/KeyEvent;)V",
		at = @At("HEAD"))
	private void onKeyPress(long windowHandle, int action, class_11908 arg,
		CallbackInfo ci)
	{
		EventManager.fire(new KeyPressEvent(arg.comp_4795(), arg.comp_4796(), action,
			arg.comp_4797()));
	}
}
