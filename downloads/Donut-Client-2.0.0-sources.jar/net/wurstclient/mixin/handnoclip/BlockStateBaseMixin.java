/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.handnoclip;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.serialization.MapCodec;

import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2688;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_4970.class_4971;
import net.wurstclient.WurstClient;
import net.wurstclient.hack.HackList;
import net.wurstclient.hacks.HandNoClipHack;

@Mixin(class_4971.class)
public abstract class BlockStateBaseMixin extends class_2688<class_2248, class_2680>
{
	private BlockStateBaseMixin(WurstClient wurst, class_2248 owner,
		Reference2ObjectArrayMap<class_2769<?>, Comparable<?>> propertyMap,
		MapCodec<class_2680> codec)
	{
		super(owner, propertyMap, codec);
	}
	
	@Inject(
		method = "getShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetShape(class_1922 view, class_2338 pos,
		class_3726 context, CallbackInfoReturnable<class_265> cir)
	{
		if(!(context instanceof class_3727 entityContext)
			|| entityContext.method_32480() == null)
			return;
		
		HackList hax = WurstClient.INSTANCE.getHax();
		if(hax == null)
			return;
		
		// RemoteView can target blocks from the camera entity
		if(entityContext.method_32480() != WurstClient.MC.field_1724
			&& entityContext.method_32480() != WurstClient.MC.method_1560())
			return;
		
		HandNoClipHack handNoClipHack = hax.handNoClipHack;
		if(!handNoClipHack.isEnabled() || handNoClipHack.isBlockInList(pos))
			return;
		
		cir.setReturnValue(class_259.method_1073());
	}
}
