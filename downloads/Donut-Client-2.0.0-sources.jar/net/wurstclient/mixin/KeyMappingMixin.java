/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.class_1041;
import net.minecraft.class_11908;
import net.minecraft.class_11910;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.wurstclient.WurstClient;
import net.wurstclient.mixinterface.IKeyMapping;

@Mixin(class_304.class)
public abstract class KeyMappingMixin implements IKeyMapping
{
	@Shadow
	private class_3675.class_306 key;
	
	@Override
	@Unique
	@Deprecated // use IKeyMapping.isActuallyDown() instead
	public boolean wurst_isActuallyDown()
	{
		class_1041 window = WurstClient.MC.method_22683();
		int code = key.method_1444();
		
		if(key.method_1442() == class_3675.class_307.field_1672)
			return GLFW.glfwGetMouseButton(window.method_4490(), code) == 1;
		
		return class_3675.method_15987(window, code);
	}
	
	@Override
	@Unique
	@Deprecated // use IKeyMapping.resetDownState() instead
	public void wurst_resetDownState()
	{
		setDown(wurst_isActuallyDown());
	}
	
	@Override
	@Unique
	@Deprecated // use IKeyMapping.simulatePress() instead
	public void wurst_simulatePress(boolean pressed)
	{
		class_310 mc = WurstClient.MC;
		class_1041 window = mc.method_22683();
		int action = pressed ? 1 : 0;
		
		switch(key.method_1442())
		{
			case field_1668:
			mc.field_1774.method_1466(window.method_4490(), action,
				new class_11908(key.method_1444(), 0, 0));
			break;
			
			case field_1671:
			mc.field_1774.method_1466(window.method_4490(), action,
				new class_11908(GLFW.GLFW_KEY_UNKNOWN, key.method_1444(), 0));
			break;
			
			case field_1672:
			mc.field_1729.method_1601(window.method_4490(),
				new class_11910(key.method_1444(), 0), action);
			break;
			
			default:
			System.out.println("Unknown key mapping type: " + key.method_1442());
			break;
		}
	}
	
	@Override
	@Shadow
	public abstract void setDown(boolean pressed);
}
