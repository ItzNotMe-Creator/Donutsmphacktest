/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import java.util.ArrayList;
import java.util.List;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.options.WurstOptionsScreen;

@Mixin(class_433.class)
public abstract class PauseScreenMixin extends class_437
{
	@Unique
	private class_4185 wurstOptionsButton;
	
	private PauseScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(method = "createPauseMenu()V", at = @At("TAIL"))
	private void onInitWidgets(CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getOtfs().wurstOptionsOtf.isVisibleInGameMenu())
			addWurstOptionsButton();
	}
	
	@Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
		at = @At("TAIL"))
	private void onRender(class_332 graphics, int mouseX, int mouseY,
		float partialTicks, CallbackInfo ci)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		if(!wurst.isEnabled())
			return;
		
		wurst.getOtfs().wurstOptionsOtf.drawWurstLogoOnButton(graphics,
			wurstOptionsButton);
	}
	
	@Unique
	private void addWurstOptionsButton()
	{
		List<class_339> buttons = Screens.getButtons(this);
		
		// Fallback position
		int buttonX = field_22789 / 2 - 102;
		int buttonY = 60;
		int buttonWidth = 204;
		int buttonHeight = 20;
		
		for(class_339 button : buttons)
		{
			// If feedback button exists, use its position
			if(isTrKey(button, "menu.sendFeedback")
				|| isTrKey(button, "menu.feedback"))
			{
				buttonY = button.method_46427();
				break;
			}
			
			// If options button exists, go 24px above it
			if(isTrKey(button, "menu.options"))
			{
				buttonY = button.method_46427() - 24;
				break;
			}
		}
		
		// Clear required space for Wurst Options
		hideFeedbackReportAndServerLinksButtons();
		ensureSpaceAvailable(buttonX, buttonY, buttonWidth, buttonHeight);
		
		// Create Wurst Options button
		wurstOptionsButton = WurstClient.INSTANCE.getOtfs().wurstOptionsOtf
			.buttonBuilder(this::openWurstOptions)
			.method_46434(buttonX, buttonY, buttonWidth, buttonHeight).method_46431();
		buttons.add(wurstOptionsButton);
	}
	
	@Unique
	private void hideFeedbackReportAndServerLinksButtons()
	{
		for(class_339 button : Screens.getButtons(this))
			if(isTrKey(button, "menu.sendFeedback")
				|| isTrKey(button, "menu.reportBugs")
				|| isTrKey(button, "menu.feedback")
				|| isTrKey(button, "menu.server_links"))
				button.field_22764 = false;
	}
	
	@Unique
	private void ensureSpaceAvailable(int x, int y, int width, int height)
	{
		// Check if there are any buttons in the way
		ArrayList<class_339> buttonsInTheWay = new ArrayList<>();
		for(class_339 button : Screens.getButtons(this))
		{
			if(button.method_55442() < x || button.method_46426() > x + width
				|| button.method_55443() < y || button.method_46427() > y + height)
				continue;
			
			if(!button.field_22764)
				continue;
			
			buttonsInTheWay.add(button);
		}
		
		// If not, we're done
		if(buttonsInTheWay.isEmpty())
			return;
		
		// If yes, clear space below and move the buttons there
		ensureSpaceAvailable(x, y + 24, width, height);
		for(class_339 button : buttonsInTheWay)
			button.method_46419(button.method_46427() + 24);
	}
	
	@Unique
	private void openWurstOptions(class_4185 button)
	{
		field_22787.method_1507(new WurstOptionsScreen(this));
	}
	
	@Unique
	private boolean isTrKey(class_339 button, String key)
	{
		String message = button.method_25369().getString();
		return message != null && message.equals(class_1074.method_4662(key));
	}
}
