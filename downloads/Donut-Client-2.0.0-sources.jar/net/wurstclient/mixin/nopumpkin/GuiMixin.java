/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.nopumpkin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.wurstclient.WurstClient;

@Mixin(class_329.class)
public class GuiMixin
{
	/**
	 * Disables the pumpkin texture overlay when NoPumpkin is enabled.
	 */
	@Inject(
		method = "renderTextureOverlay(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/resources/Identifier;F)V",
		at = @At("HEAD"),
		cancellable = true)
	private void onRenderTextureOverlay(class_332 graphics,
		class_2960 texture, float opacity, CallbackInfo ci)
	{
		if(texture == null)
			return;
		
		if("textures/misc/pumpkinblur.png".equals(texture.method_12832())
			&& WurstClient.INSTANCE.getHax().noPumpkinHack.isEnabled())
			ci.cancel();
	}
}
