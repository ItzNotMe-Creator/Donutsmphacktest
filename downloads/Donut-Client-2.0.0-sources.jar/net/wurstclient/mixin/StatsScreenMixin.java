/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_447;
import net.minecraft.class_8021;
import net.minecraft.class_8132;
import net.minecraft.class_8667;
import net.wurstclient.WurstClient;
import net.wurstclient.options.WurstOptionsScreen;

@Mixin(class_447.class)
public abstract class StatsScreenMixin extends class_437
{
	@Unique
	private class_4185 wurstOptionsButton;
	
	public StatsScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@WrapOperation(method = "init()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/gui/layouts/HeaderAndFooterLayout;addToFooter(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;",
			ordinal = 0))
	private <T extends class_8021> T onAddToFooter(
		class_8132 layout, T doneWidget, Operation<T> original)
	{
		if(!(doneWidget instanceof class_4185 doneButton))
			throw new IllegalStateException(
				"The done button in the statistics screen somehow isn't a button");
		
		WurstClient wurst = WurstClient.INSTANCE;
		if(wurst.getOtfs().disableOtf.shouldHideEnableButton())
			return original.call(layout, doneButton);
		
		class_8667 vLayout = class_8667.method_52741().method_52735(5);
		class_8667 hLayout = class_8667.method_52742().method_52735(5);
		
		class_4185 toggleButton =
			class_4185.method_46430(getToggleButtonText(), this::toggleWurst).method_46432(100)
				.method_46431();
		hLayout.method_52736(toggleButton);
		
		doneButton.method_25358(100);
		hLayout.method_52736(doneButton);
		
		if(wurst.getOtfs().wurstOptionsOtf.isVisibleInStatistics())
		{
			layout.method_48991(58);
			wurstOptionsButton = WurstClient.INSTANCE.getOtfs().wurstOptionsOtf
				.buttonBuilder(this::openWurstOptions).method_46432(205).method_46431();
			vLayout.method_52736(wurstOptionsButton);
		}
		
		vLayout.method_52736(hLayout);
		return original.call(layout, vLayout);
	}
	
	@Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
		at = @At("TAIL"))
	private void onRender(class_332 graphics, int mouseX, int mouseY,
		float partialTicks, CallbackInfo ci)
	{
		WurstClient.INSTANCE.getOtfs().wurstOptionsOtf
			.drawWurstLogoOnButton(graphics, wurstOptionsButton);
	}
	
	@Unique
	private void openWurstOptions(class_4185 button)
	{
		field_22787.method_1507(new WurstOptionsScreen(this));
	}
	
	@Unique
	private void toggleWurst(class_4185 toggleButton)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		wurst.setEnabled(!wurst.isEnabled());
		toggleButton.method_25355(getToggleButtonText());
		if(wurstOptionsButton != null)
			wurstOptionsButton.field_22763 = wurst.isEnabled();
	}
	
	@Unique
	private class_2561 getToggleButtonText()
	{
		WurstClient wurst = WurstClient.INSTANCE;
		String text = (wurst.isEnabled() ? "Disable" : "Enable") + " Wurst";
		return class_2561.method_43470(text);
	}
}
