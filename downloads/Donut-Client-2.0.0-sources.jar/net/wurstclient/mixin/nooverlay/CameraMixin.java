/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.nooverlay;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.wurstclient.WurstClient;

@Mixin(class_4184.class)
public abstract class CameraMixin
{
	/**
	 * Disables water, lava, and powder snow fog when NoOverlay is enabled. Also
	 * prevents the FOV reduction in water and lava.
	 */
	@Inject(
		method = "getFluidInCamera()Lnet/minecraft/world/level/material/FogType;",
		at = @At("HEAD"),
		cancellable = true)
	private void onGetFluidInCamera(CallbackInfoReturnable<class_5636> cir)
	{
		if(WurstClient.INSTANCE.getHax().noOverlayHack.isEnabled())
			cir.setReturnValue(class_5636.field_27888);
	}
}
