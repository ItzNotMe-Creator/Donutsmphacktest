/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.wurstclient.InputFaker;
import net.wurstclient.InputFaker.TempRealInput;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.IsPlayerInWaterListener.IsPlayerInWaterEvent;
import net.wurstclient.events.MobEffectListener.MobEffectEvent;
import net.wurstclient.events.PostMotionListener.PostMotionEvent;
import net.wurstclient.events.PreMotionListener.PreMotionEvent;
import net.wurstclient.events.UpdateListener.UpdateEvent;
import net.wurstclient.mixinterface.ILocalPlayer;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_742
	implements ILocalPlayer
{
	private LocalPlayerMixin(WurstClient wurst, class_638 world,
		GameProfile profile)
	{
		super(world, profile);
	}
	
	@Inject(method = {"tick()V", "rideTick()V"}, at = @At("HEAD"))
	private void onTickHead(CallbackInfo ci)
	{
		InputFaker.swapIfNeeded();
	}
	
	@Inject(method = {"tick()V", "rideTick()V"}, at = @At("RETURN"))
	private void onInputFakerReturn(CallbackInfo ci)
	{
		InputFaker.restoreIfNeeded();
	}
	
	@Inject(method = "tick()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/AbstractClientPlayer;tick()V",
			ordinal = 0))
	private void onTick(CallbackInfo ci)
	{
		try(TempRealInput ignore = new TempRealInput())
		{
			EventManager.fire(UpdateEvent.INSTANCE);
		}
	}
	
	@Inject(method = "tick()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/LocalPlayer;isPassenger()Z"))
	private void onTickPreMotion(CallbackInfo ci)
	{
		EventManager.fire(PreMotionEvent.INSTANCE);
	}
	
	@Inject(method = "tick()V",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/player/LocalPlayer;ambientSoundHandlers:Ljava/util/List;"))
	private void onTickPostMotion(CallbackInfo ci)
	{
		EventManager.fire(PostMotionEvent.INSTANCE);
	}
	
	@Inject(method = "sendPosition()V", at = @At("HEAD"))
	private void onSendPositionHEAD(CallbackInfo ci)
	{
		// Run RotationFaker after events so PreMotionListeners can use it
		WurstClient.INSTANCE.getRotationFaker().applyIfNeeded();
	}
	
	@Inject(method = "sendPosition()V", at = @At("TAIL"))
	private void onSendPositionTAIL(CallbackInfo ci)
	{
		WurstClient.INSTANCE.getRotationFaker().restoreIfNeeded();
	}
	
	/**
	 * Prevents vanilla auto-jump from interfering with Step and .goto.
	 */
	@ModifyExpressionValue(method = "updateAutoJump(FF)V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/LocalPlayer;canAutoJump()Z"))
	private boolean modifyCanAutoJump(boolean original)
	{
		return original && !WurstClient.INSTANCE.getHax().stepHack.isEnabled()
			&& !WurstClient.INSTANCE.getCmds().goToCmd.isActive();
	}
	
	@Override
	public boolean method_5799()
	{
		boolean inWater = super.method_5799();
		IsPlayerInWaterEvent event = new IsPlayerInWaterEvent(inWater);
		EventManager.fire(event);
		
		return event.isInWater();
	}
	
	@Override
	public boolean isInWaterBypass()
	{
		return super.method_5799();
	}
	
	@Override
	public boolean method_6059(class_6880<class_1291> effect)
	{
		return method_6112(effect) != null;
	}
	
	@Override
	public class_1293 method_6112(class_6880<class_1291> effect)
	{
		MobEffectEvent event =
			new MobEffectEvent(effect, super.method_6112(effect));
		EventManager.fire(event);
		return event.getInstance();
	}
}
