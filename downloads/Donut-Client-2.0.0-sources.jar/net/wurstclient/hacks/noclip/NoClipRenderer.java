/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.noclip;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.wurstclient.WurstClient;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.hacks.NoClipHack;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RenderUtils;

public enum NoClipRenderer
{
	;
	
	private static final class_310 MC = WurstClient.MC;
	
	public static Set<JumpToRender> findJumpsNear(class_2338 center)
	{
		Set<JumpToRender> jumps = new LinkedHashSet<>();
		for(class_2338 pos : BlockUtils.getAllInBox(center, 3))
		{
			if(pos.method_19455(center) > 3)
				continue;
			
			if(!MC.field_1687.method_8477(pos)
				|| !MC.field_1687.method_8320(pos).method_26216())
				continue;
			
			for(class_2350 direction : class_2350.values())
			{
				JumpToRender jump = findJump(pos, direction);
				if(jump != null)
					jumps.add(jump);
			}
		}
		
		return jumps;
	}
	
	private static JumpToRender findJump(class_2338 entryPos, class_2350 direction)
	{
		class_2338 preEntryPos = entryPos.method_10093(direction.method_10153());
		if(!MC.field_1687.method_8477(preEntryPos)
			|| MC.field_1687.method_8320(preEntryPos).method_26216())
			return null;
		
		for(int blocks = 1; blocks + 1 <= NoClipHack.MAX_DISTANCE; blocks++)
		{
			class_2338 exitPos = entryPos.method_10079(direction, blocks - 1);
			class_2338 postExitPos = exitPos.method_10093(direction);
			if(!MC.field_1687.method_8477(postExitPos))
				return null;
			if(MC.field_1687.method_8320(postExitPos).method_26216())
				continue;
			
			class_2338 minPos =
				direction.method_10171() == class_2352.field_11056
					? entryPos : exitPos;
			return new JumpToRender(minPos, direction.method_10166(), blocks,
				blocks + 1 > NoClipHack.MAX_DISTANCE_WITHOUT_ELYTRA);
		}
		return null;
	}
	
	public static void renderJumps(class_4587 matrixStack,
		Collection<JumpToRender> jumps)
	{
		if(jumps.isEmpty())
			return;
		
		class_4597.class_4598 vcp = RenderUtils.getVCP();
		class_4588 buffer = vcp.method_73477(WurstRenderLayers.ESP_LINES);
		class_243 cameraPos = RenderUtils.getCameraPos();
		for(JumpToRender jump : jumps)
			drawJump(matrixStack, buffer, jump, cameraPos);
		vcp.method_22994(WurstRenderLayers.ESP_LINES);
	}
	
	private static void drawJump(class_4587 matrixStack, class_4588 buffer,
		JumpToRender jump, class_243 cameraPos)
	{
		int color = jump.needsElytra() ? 0x8000FFFF : 0x8000FF00;
		class_2351 normalAxis = jump.axis();
		class_243 minFaceCenter = class_243.method_24953(jump.minPos())
			.method_38499(normalAxis, jump.minPos().method_30558(normalAxis))
			.method_1020(cameraPos);
		class_243 maxFaceCenter = minFaceCenter.method_38499(normalAxis,
			minFaceCenter.method_18043(normalAxis) + jump.blocks());
		class_243 halfWidth =
			(normalAxis == class_2351.field_11048 ? class_243.field_61916 : class_243.field_61914).method_1021(7 / 16.0);
		class_243 halfHeight =
			(normalAxis == class_2351.field_11052 ? class_243.field_61916 : class_243.field_61915).method_1021(7 / 16.0);
		for(class_243 center : new class_243[]{minFaceCenter, maxFaceCenter})
		{
			class_243 a = center.method_1020(halfWidth).method_1020(halfHeight);
			class_243 b = center.method_1019(halfWidth).method_1020(halfHeight);
			class_243 c = center.method_1019(halfWidth).method_1019(halfHeight);
			class_243 d = center.method_1020(halfWidth).method_1019(halfHeight);
			RenderUtils.drawLine(matrixStack, buffer, a, b, color);
			RenderUtils.drawLine(matrixStack, buffer, b, c, color);
			RenderUtils.drawLine(matrixStack, buffer, c, d, color);
			RenderUtils.drawLine(matrixStack, buffer, d, a, color);
		}
	}
	
	public record JumpToRender(class_2338 minPos, class_2351 axis, int blocks,
		boolean needsElytra)
	{}
}
