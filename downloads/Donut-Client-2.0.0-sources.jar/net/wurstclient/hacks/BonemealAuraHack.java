/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2372;
import net.minecraft.class_2472;
import net.minecraft.class_2473;
import net.minecraft.class_2513;
import net.minecraft.class_2680;
import net.minecraft.world.level.block.*;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleInputListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.FaceTargetSetting;
import net.wurstclient.settings.FaceTargetSetting.FaceTarget;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.settings.TakeItemsFromSetting;
import net.wurstclient.settings.TakeItemsFromSetting.TakeItemsFrom;
import net.wurstclient.util.BlockBreaker;
import net.wurstclient.util.BlockBreaker.BlockBreakingParams;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InteractionSimulator;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"bonemeal aura", "bone meal aura", "AutoBonemeal", "auto bonemeal",
	"auto bone meal", "fertilizer", "bmaura"})
public final class BonemealAuraHack extends Hack implements HandleInputListener
{
	private final SliderSetting range =
		new SliderSetting("Range", 5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting multiMeal = new CheckboxSetting("MultiMeal",
		"description.wurst.setting.bonemealaura.multimeal", false);
	
	private final CheckboxSetting checkLOS =
		new CheckboxSetting("Check line of sight",
			"description.wurst.setting.bonemealaura.check_los", true);
	
	private final FaceTargetSetting faceTarget =
		FaceTargetSetting.withPacketSpam(this, FaceTarget.SERVER);
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.CLIENT);
	
	private final CheckboxSetting fastPlace =
		new CheckboxSetting("Always FastPlace",
			"description.wurst.setting.bonemealaura.always_fastplace", true);
	
	private final CheckboxSetting useWhileBreaking =
		new CheckboxSetting("Use while breaking",
			"description.wurst.setting.bonemealaura.use_while_breaking", false);
	
	private final CheckboxSetting useWhileRiding =
		new CheckboxSetting("Use while riding",
			"description.wurst.setting.bonemealaura.use_while_riding", false);
	
	private final TakeItemsFromSetting takeItemsFrom =
		TakeItemsFromSetting.withHands(this, TakeItemsFrom.HANDS);
	
	private final CheckboxSetting saplings =
		new CheckboxSetting("Saplings", true);
	
	private final CheckboxSetting crops = new CheckboxSetting("Crops",
		"Wheat, carrots, potatoes and beetroots.", true);
	
	private final CheckboxSetting stems =
		new CheckboxSetting("Stems", "Pumpkins and melons.", true);
	
	private final CheckboxSetting cocoa = new CheckboxSetting("Cocoa", true);
	
	private final CheckboxSetting seaPickles =
		new CheckboxSetting("Sea pickles", true);
	
	private final CheckboxSetting other = new CheckboxSetting("Other", false);
	
	public BonemealAuraHack()
	{
		super("BonemealAura");
		setCategory(Category.BLOCKS);
		addSetting(range);
		addSetting(multiMeal);
		addSetting(checkLOS);
		addSetting(faceTarget);
		addSetting(swingHand);
		addSetting(fastPlace);
		addSetting(useWhileBreaking);
		addSetting(useWhileRiding);
		addSetting(takeItemsFrom);
		addSetting(saplings);
		addSetting(crops);
		addSetting(stems);
		addSetting(cocoa);
		addSetting(seaPickles);
		addSetting(other);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(HandleInputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(HandleInputListener.class, this);
	}
	
	@Override
	public void onHandleInput()
	{
		if(!fastPlace.isChecked() && MC.field_1752 > 0)
			return;
		
		if(!useWhileBreaking.isChecked() && MC.field_1761.method_2923())
			return;
		
		if(!useWhileRiding.isChecked() && MC.field_1724.method_3144())
			return;
		
		if(WURST.getHax().autoFarmHack.isBusy())
			return;
		
		boolean holdingBoneMeal = MC.field_1724.method_24518(class_1802.field_8324);
		int boneMealSlot = InventoryUtils.indexOf(class_1802.field_8324,
			takeItemsFrom.getMaxInvSlot());
		if(!holdingBoneMeal && boneMealSlot < 0)
			return;
		
		List<BlockBreakingParams> validBlocks = getValidBlocks();
		if(validBlocks.isEmpty())
			return;
		
		if(!holdingBoneMeal)
		{
			InventoryUtils.selectItem(boneMealSlot);
			return;
		}
		
		if(multiMeal.isChecked())
		{
			boolean shouldSwing = false;
			
			for(BlockBreakingParams params : validBlocks)
			{
				faceTarget.face(params.hitVec());
				InteractionSimulator.rightClickBlock(params.toHitResult(),
					SwingHand.OFF);
				shouldSwing = true;
			}
			
			if(shouldSwing)
				swingHand.swing(class_1268.field_5808);
			
		}else
		{
			BlockBreakingParams params = validBlocks.getFirst();
			MC.field_1752 = 4;
			faceTarget.face(params.hitVec());
			InteractionSimulator.rightClickBlock(params.toHitResult(),
				swingHand.getSelected());
		}
	}
	
	private List<BlockBreakingParams> getValidBlocks()
	{
		class_2338 eyesBlock = class_2338.method_49638(MC.field_1724.method_33571());
		double rangeSq = range.getValueSq();
		
		Stream<BlockBreakingParams> stream = BlockUtils
			.getAllInBoxStream(eyesBlock, range.getValueCeil())
			.filter(this::isCorrectBlock)
			.map(BlockBreaker::getBlockBreakingParams).filter(Objects::nonNull)
			.filter(params -> params.distanceSq() <= rangeSq);
		
		if(checkLOS.isChecked())
			stream = stream.filter(BlockBreakingParams::lineOfSight);
			
		// As plants are bone-mealed, they will grow larger and prevent line of
		// sight to other plants behind them. That's why we need to bone-meal
		// the farthest plants first.
		Comparator<BlockBreakingParams> farthestFirst = Comparator
			.comparingDouble(BlockBreakingParams::distanceSq).reversed();
		stream = stream.sorted(farthestFirst);
		
		return stream.toList();
	}
	
	private boolean isCorrectBlock(class_2338 pos)
	{
		class_2248 block = BlockUtils.getBlock(pos);
		class_2680 state = BlockUtils.getState(pos);
		
		if(!(block instanceof class_2256 bmBlock)
			|| !bmBlock.method_9651(MC.field_1687, pos, state))
			return false;
		
		if(block instanceof class_2372)
			return false;
		
		if(block instanceof class_2473)
			return saplings.isChecked();
		
		if(block instanceof class_2302)
			return crops.isChecked();
		
		if(block instanceof class_2513)
			return stems.isChecked();
		
		if(block instanceof class_2282)
			return cocoa.isChecked();
		
		if(block instanceof class_2472)
			return seaPickles.isChecked();
		
		return other.isChecked();
	}
}
