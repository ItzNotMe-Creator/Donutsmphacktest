/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofarm.plants;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.autofarm.AutoFarmPlantType;
import net.wurstclient.settings.PlantTypeSetting;
import net.wurstclient.util.BlockUtils;

public final class WeepingVinesPlantType extends AutoFarmPlantType
{
	@Override
	public final boolean isReplantingSpot(class_2338 pos, class_2680 state)
	{
		return (state.method_27852(class_2246.field_22123)
			|| state.method_27852(class_2246.field_22124)) && hasPlantingSurface(pos);
	}
	
	@Override
	public final boolean hasPlantingSurface(class_2338 pos)
	{
		class_2338 ceilPos = pos.method_10084();
		class_2680 ceilState = BlockUtils.getState(ceilPos);
		return !ceilState.method_27852(class_2246.field_22123)
			&& !ceilState.method_27852(class_2246.field_22124) && ceilState
				.method_26206(WurstClient.MC.field_1687, ceilPos, class_2350.field_11033);
	}
	
	@Override
	public class_1792 getSeedItem()
	{
		return class_1802.field_21992;
	}
	
	@Override
	public boolean shouldHarvestByMining(class_2338 pos, class_2680 state)
	{
		return (state.method_27852(class_2246.field_22123)
			|| state.method_27852(class_2246.field_22124))
			&& !isReplantingSpot(pos, state);
	}
	
	@Override
	protected PlantTypeSetting createSetting()
	{
		return new PlantTypeSetting("Weeping vines", class_1802.field_21992, false,
			false);
	}
}
