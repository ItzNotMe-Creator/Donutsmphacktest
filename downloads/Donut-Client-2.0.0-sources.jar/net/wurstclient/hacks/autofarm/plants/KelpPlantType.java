/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofarm.plants;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.autofarm.AutoFarmPlantType;
import net.wurstclient.settings.PlantTypeSetting;
import net.wurstclient.util.BlockUtils;

public final class KelpPlantType extends AutoFarmPlantType
{
	// KELP is the tip, KELP_PLANT is any other part below that.
	// Either one can be the stem, depending on the size of the plant.
	
	@Override
	public final boolean isReplantingSpot(class_2338 pos, class_2680 state)
	{
		if(!state.method_27852(class_2246.field_9993) && !state.method_27852(class_2246.field_10463))
			return false;
		
		class_2680 floor = BlockUtils.getState(pos.method_10074());
		return !floor.method_27852(class_2246.field_9993) && !floor.method_27852(class_2246.field_10463)
			&& hasPlantingSurface(pos);
	}
	
	@Override
	public final boolean hasPlantingSurface(class_2338 pos)
	{
		class_3610 fluid = BlockUtils.getState(pos).method_26227();
		if(!fluid.method_15767(class_3486.field_15517) || fluid.method_15761() != 8)
			return false;
		
		class_2338 floorPos = pos.method_10074();
		class_2680 floorState = BlockUtils.getState(floorPos);
		return !floorState.method_27852(class_2246.field_10092) && floorState
			.method_26206(WurstClient.MC.field_1687, floorPos, class_2350.field_11036);
	}
	
	@Override
	public class_1792 getSeedItem()
	{
		return class_1802.field_17532;
	}
	
	@Override
	public boolean shouldHarvestByMining(class_2338 pos, class_2680 state)
	{
		if(!state.method_27852(class_2246.field_9993) && !state.method_27852(class_2246.field_10463))
			return false;
		
		class_2338 below = pos.method_10074();
		return isReplantingSpot(below, BlockUtils.getState(below));
	}
	
	@Override
	protected PlantTypeSetting createSetting()
	{
		return new PlantTypeSetting("Kelp", class_1802.field_17532, true, true);
	}
}
