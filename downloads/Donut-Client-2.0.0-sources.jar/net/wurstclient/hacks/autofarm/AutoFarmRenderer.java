/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofarm;

import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.Setting;
import net.wurstclient.util.RenderUtils;

public final class AutoFarmRenderer
{
	private static final class_238 BLOCK_BOX =
		new class_238(class_2338.field_10980).method_1011(1 / 16.0);
	private static final class_238 NODE_BOX = new class_238(class_2338.field_10980).method_1011(0.25);
	
	public final CheckboxSetting drawReplantingSpots =
		new CheckboxSetting("Draw replanting spots", true);
	public final CheckboxSetting drawBlocksToHarvest =
		new CheckboxSetting("Draw blocks to harvest", true);
	public final CheckboxSetting drawBlocksToReplant =
		new CheckboxSetting("Draw blocks to replant", true);
	
	private List<class_238> replantingSpots = List.of();
	private List<class_238> blocksToHarvest = List.of();
	private List<class_238> blocksToReplant = List.of();
	
	public void update(Collection<class_2338> replantingSpots,
		Collection<class_2338> blocksToHarvest,
		Collection<class_2338> blocksToReplant)
	{
		this.replantingSpots =
			replantingSpots.stream().map(NODE_BOX::method_996).toList();
		this.blocksToHarvest =
			blocksToHarvest.stream().map(BLOCK_BOX::method_996).toList();
		this.blocksToReplant =
			blocksToReplant.stream().map(BLOCK_BOX::method_996).toList();
	}
	
	public void render(class_4587 matrixStack)
	{
		if(drawReplantingSpots.isChecked())
			RenderUtils.drawNodes(matrixStack, replantingSpots, 0x8000FFFF,
				false);
		
		if(drawBlocksToHarvest.isChecked())
			RenderUtils.drawOutlinedBoxes(matrixStack, blocksToHarvest,
				0x8000FF00, false);
		
		if(drawBlocksToReplant.isChecked())
			RenderUtils.drawOutlinedBoxes(matrixStack, blocksToReplant,
				0x80FF0000, false);
	}
	
	public Stream<Setting> getSettings()
	{
		return Stream.of(drawReplantingSpots, drawBlocksToHarvest,
			drawBlocksToReplant);
	}
}
