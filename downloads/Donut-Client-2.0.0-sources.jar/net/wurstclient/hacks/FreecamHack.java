/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.CameraTransformViewBobbingListener;
import net.wurstclient.events.MouseScrollListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.events.VisGraphListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.freecam.FreecamInitialPosSetting;
import net.wurstclient.hacks.freecam.FreecamInputSetting;
import net.wurstclient.hacks.freecam.FreecamInputSetting.ApplyInputTo;
import net.wurstclient.mixinterface.IKeyMapping;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.InteractFromSetting;
import net.wurstclient.settings.InteractFromSetting.InteractFrom;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;

@DontSaveState
@SearchTags({"free camera", "spectator"})
public final class FreecamHack extends Hack
	implements UpdateListener, VisGraphListener,
	CameraTransformViewBobbingListener, RenderListener, MouseScrollListener
{
	private final FreecamInputSetting applyInputTo = new FreecamInputSetting();
	
	private final InteractFromSetting interactFrom =
		new InteractFromSetting(this, InteractFrom.CAMERA);
	
	private final SliderSetting horizontalSpeed =
		new SliderSetting("Horizontal speed",
			"description.wurst.setting.freecam.horizontal_speed", 1, 0.05, 10,
			0.05, ValueDisplay.DECIMAL);
	
	private final SliderSetting verticalSpeed = new SliderSetting(
		"Vertical speed", "description.wurst.setting.freecam.vertical_speed", 1,
		0.05, 5, 0.05,
		v -> ValueDisplay.DECIMAL.getValueString(getActualVerticalSpeed()));
	
	private final CheckboxSetting scrollToChangeSpeed =
		new CheckboxSetting("Scroll to change speed",
			"description.wurst.setting.freecam.scroll_to_change_speed", true);
	
	private final CheckboxSetting renderSpeed =
		new CheckboxSetting("Show speed in HackList",
			"description.wurst.setting.freecam.show_speed_in_hacklist", true);
	
	private final FreecamInitialPosSetting initialPos =
		new FreecamInitialPosSetting();
	
	private final CheckboxSetting tracer = new CheckboxSetting("Tracer",
		"description.wurst.setting.freecam.tracer", false);
	
	private final ColorSetting color =
		new ColorSetting("Tracer color", Color.WHITE);
	
	private final CheckboxSetting hideHand = new CheckboxSetting("Hide hand",
		"description.wurst.setting.freecam.hide_hand", true);
	
	private final CheckboxSetting disableOnDamage =
		new CheckboxSetting("Disable on damage",
			"description.wurst.setting.freecam.disable_on_damage", true);
	
	private final CheckboxSetting reloadChunks =
		new CheckboxSetting("Reload chunks",
			"description.wurst.setting.freecam.reload_chunks", true);
	
	private class_243 camPos;
	private class_243 prevCamPos;
	private float camYaw;
	private float camPitch;
	private float lastHealth;
	
	public FreecamHack()
	{
		super("Freecam");
		setCategory(Category.RENDER);
		addSetting(applyInputTo);
		addSetting(interactFrom);
		addSetting(horizontalSpeed);
		addSetting(verticalSpeed);
		addSetting(scrollToChangeSpeed);
		addSetting(renderSpeed);
		addSetting(initialPos);
		addSetting(tracer);
		addSetting(color);
		addSetting(hideHand);
		addSetting(disableOnDamage);
		addSetting(reloadChunks);
	}
	
	@Override
	public String getRenderName()
	{
		if(!renderSpeed.isChecked())
			return getName();
		
		return getName() + " [" + horizontalSpeed.getValueString() + ", "
			+ verticalSpeed.getValueString() + "]";
	}
	
	@Override
	protected void onEnable()
	{
		class_1297 cameraEntity =
			Optional.ofNullable(MC.method_1560()).orElse(MC.field_1724);
		
		WURST.getHax().remoteViewHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(VisGraphListener.class, this);
		EVENTS.add(CameraTransformViewBobbingListener.class, this);
		EVENTS.add(RenderListener.class, this);
		EVENTS.add(MouseScrollListener.class, this);
		
		lastHealth = Float.MIN_VALUE;
		camPos = initialPos.getSelected().getPos(cameraEntity);
		prevCamPos = camPos;
		camYaw = cameraEntity.method_5705(1);
		camPitch = cameraEntity.method_5695(1);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(VisGraphListener.class, this);
		EVENTS.remove(CameraTransformViewBobbingListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		EVENTS.remove(MouseScrollListener.class, this);
		
		if(reloadChunks.isChecked())
			MC.field_1769.method_3279();
	}
	
	@Override
	public void onUpdate()
	{
		class_746 player = MC.field_1724;
		
		// Check for damage
		float currentHealth = player.method_6032();
		if(disableOnDamage.isChecked() && currentHealth < lastHealth)
		{
			setEnabled(false);
			return;
		}
		lastHealth = currentHealth;
		
		if(!isMovingCamera() || MC.field_1755 != null)
		{
			prevCamPos = camPos;
			return;
		}
		
		// Get movement vector (x=left, y=forward)
		class_241 moveVector = player.field_3913.method_3128();
		
		// Convert to world coordinates
		double yawRad = MC.field_1773.method_19418().method_19330() * class_3532.field_29847;
		double sinYaw = class_3532.method_15374(yawRad);
		double cosYaw = class_3532.method_15362(yawRad);
		double offsetX = moveVector.field_1343 * cosYaw - moveVector.field_1342 * sinYaw;
		double offsetZ = moveVector.field_1343 * sinYaw + moveVector.field_1342 * cosYaw;
		
		// Calculate vertical offset
		double offsetY = 0;
		double vSpeed = getActualVerticalSpeed();
		if(IKeyMapping.get(MC.field_1690.field_1903).isActuallyDown())
			offsetY += vSpeed;
		if(IKeyMapping.get(MC.field_1690.field_1832).isActuallyDown())
			offsetY -= vSpeed;
		
		// Apply to camera
		class_243 offsetVec = new class_243(offsetX, 0, offsetZ)
			.method_1021(horizontalSpeed.getValueF()).method_1031(0, offsetY, 0);
		prevCamPos = camPos;
		camPos = camPos.method_1019(offsetVec);
	}
	
	private double getActualVerticalSpeed()
	{
		return Math.clamp(horizontalSpeed.getValue() * verticalSpeed.getValue(),
			0.05, 10);
	}
	
	@Override
	public void onMouseScroll(double amount)
	{
		if(!isControllingScrollEvents())
			return;
		
		if(amount > 0)
			horizontalSpeed.increaseValue();
		else if(amount < 0)
			horizontalSpeed.decreaseValue();
	}
	
	public boolean isControllingScrollEvents()
	{
		return isMovingCamera() && scrollToChangeSpeed.isChecked()
			&& MC.field_1755 == null
			&& !WURST.getOtfs().zoomOtf.isControllingScrollEvents();
	}
	
	public boolean isMovingCamera()
	{
		return isEnabled() && applyInputTo.getSelected() == ApplyInputTo.CAMERA;
	}
	
	public boolean isClickingFromCamera()
	{
		return isEnabled() && interactFrom.getSelected() == InteractFrom.CAMERA;
	}
	
	@Override
	public void onVisGraph(VisGraphEvent event)
	{
		event.cancel();
	}
	
	@Override
	public void onCameraTransformViewBobbing(
		CameraTransformViewBobbingEvent event)
	{
		event.cancel();
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(!tracer.isChecked())
			return;
		
		int colorI = color.getColorI(0x80);
		
		// Box
		double extraSize = 0.05;
		class_238 rawBox = EntityUtils.getLerpedBox(MC.field_1724, partialTicks);
		class_238 box = rawBox.method_989(0, extraSize, 0).method_1014(extraSize);
		RenderUtils.drawOutlinedBox(matrixStack, box, colorI, false);
		
		// Line
		RenderUtils.drawTracer(matrixStack, partialTicks, rawBox.method_1005(),
			colorI, false);
	}
	
	public boolean shouldHideHand()
	{
		return isEnabled() && hideHand.isChecked();
	}
	
	public class_243 getCamPos(float partialTicks)
	{
		return class_3532.method_61342(partialTicks, prevCamPos, camPos);
	}
	
	public void turn(double deltaYaw, double deltaPitch)
	{
		// This needs to be consistent with Entity.turn()
		camYaw += (float)(deltaYaw * 0.15);
		camPitch += (float)(deltaPitch * 0.15);
		camPitch = Math.clamp(camPitch, -90, 90);
	}
	
	public float getCamYaw()
	{
		return camYaw;
	}
	
	public float getCamPitch()
	{
		return camPitch;
	}
	
	public class_243 getScaledCamDir(double scale)
	{
		return class_243.method_1030(camPitch, camYaw).method_1021(scale);
	}
}
