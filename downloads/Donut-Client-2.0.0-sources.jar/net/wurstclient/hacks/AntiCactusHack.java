/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2828.class_2829;
import net.minecraft.class_634;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PreMotionListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;

@SearchTags({"NoCactus", "anti cactus", "no cactus"})
public final class AntiCactusHack extends Hack implements PreMotionListener
{
	private static final class_265 VANILLA_HEIGHT_CACTUS_SHAPE =
		class_2248.method_66404(16, 0, 15);
	
	private final CheckboxSetting preventCactusTopDamage = new CheckboxSetting(
		"Prevent cactus-top damage",
		"description.wurst.setting.anticactus.prevent_cactus-top_damage", true);
	
	public AntiCactusHack()
	{
		super("AntiCactus");
		setCategory(Category.BLOCKS);
		addSetting(preventCactusTopDamage);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PreMotionListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PreMotionListener.class, this);
	}
	
	public class_265 getCollisionShape()
	{
		return preventCactusTopDamage.isChecked() ? class_259.method_1077()
			: VANILLA_HEIGHT_CACTUS_SHAPE;
	}
	
	@Override
	public void onPreMotion()
	{
		if(MC.field_1724.method_5765())
			return;
		
		if(!preventCactusTopDamage.isChecked()
			|| MC.field_1724.method_18798().field_1351 > 0 || !isAboveCactus())
			return;
		
		class_243 pos = MC.field_1724.method_73189();
		boolean hCollision = MC.field_1724.field_5976;
		class_634 connection = MC.field_1724.field_3944;
		
		connection.method_52787(new class_2829(pos, true, hCollision));
		connection.method_52787(new class_2829(pos.method_1031(0, 1e-6, 0), false, hCollision));
		connection.method_52787(new class_2829(pos, true, hCollision));
	}
	
	private boolean isAboveCactus()
	{
		class_238 below = MC.field_1724.method_5829().method_989(0, -2, 0);
		class_2338 min = class_2338.method_49637(below.field_1323, below.field_1322, below.field_1321);
		class_2338 max =
			class_2338.method_49637(below.field_1320, MC.field_1724.method_23318(), below.field_1324);
		
		for(class_2338 pos : class_2338.method_10097(min, max))
			if(MC.field_1687.method_8320(pos).method_27852(class_2246.field_10029)
				&& MC.field_1724.method_23318() >= pos.method_10264() + 1)
				return true;
			
		return false;
	}
}
