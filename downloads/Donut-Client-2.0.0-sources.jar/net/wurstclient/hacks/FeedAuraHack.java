/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleInputListener;
import net.wurstclient.events.PreMotionListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.filters.FilterBabiesSetting;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;

@SearchTags({"feed aura", "BreedAura", "breed aura", "AutoBreeder",
	"auto breeder"})
public final class FeedAuraHack extends Hack
	implements PreMotionListener, HandleInputListener, RenderListener
{
	private final SliderSetting range = new SliderSetting("Range",
		"Determines how far FeedAura will reach to feed animals.\n"
			+ "Anything that is further away than the specified value will not be fed.",
		5, 1, 10, 0.05, ValueDisplay.DECIMAL);
	
	private final FilterBabiesSetting filterBabies =
		new FilterBabiesSetting(this, true);
	
	private final CheckboxSetting filterUntamed =
		new CheckboxSetting("Filter untamed",
			"description.wurst.setting.feedaura.filter_untamed", false);
	
	private final CheckboxSetting filterHorses =
		new CheckboxSetting("Filter horse-like animals",
			"description.wurst.setting.feedaura.filter_horses", false);
	
	private final Random random = new Random();
	private class_1309 clickTarget;
	private class_1309 renderTarget;
	
	public FeedAuraHack()
	{
		super("FeedAura");
		setCategory(Category.OTHER);
		addSetting(range);
		addSetting(filterBabies);
		addSetting(filterUntamed);
		addSetting(filterHorses);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PreMotionListener.class, this);
		EVENTS.add(HandleInputListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PreMotionListener.class, this);
		EVENTS.remove(HandleInputListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		clickTarget = null;
		renderTarget = null;
	}
	
	@Override
	public void onPreMotion()
	{
		class_1799 heldStack = MC.field_1724.method_31548().method_7391();
		double rangeSq = range.getValueSq();
		
		List<class_1309> targets = EntityUtils
			.getAliveEntities(class_1309.class)
			.filter(e -> EntityUtils.distanceToHitboxSq(e) <= rangeSq)
			.filter(e -> canFeed(e, heldStack)).filter(filterBabies)
			.filter(e -> !filterUntamed.isChecked() || !isUntamed(e))
			.filter(
				e -> !filterHorses.isChecked() || !(e instanceof class_1496))
			.toList();
		
		if(targets.isEmpty())
		{
			clickTarget = null;
			renderTarget = null;
			return;
		}
		
		clickTarget = targets.get(random.nextInt(targets.size()));
		renderTarget = clickTarget;
		WURST.getRotationFaker()
			.faceVectorPacket(clickTarget.method_5829().method_1005());
	}
	
	private boolean canFeed(class_1309 entity, class_1799 stack)
	{
		if(entity instanceof class_1429 animal)
			return animal.method_6481(stack) && animal.method_6482();
		
		return false;
	}
	
	private boolean isUntamed(class_1309 entity)
	{
		return entity instanceof class_1496 horse && !horse.method_6727()
			|| entity instanceof class_1321 animal && !animal.method_6181();
	}
	
	@Override
	public void onHandleInput()
	{
		if(clickTarget == null)
			return;
		
		class_636 gm = MC.field_1761;
		class_746 player = MC.field_1724;
		
		if(gm.method_2923() || player.method_3144())
			return;
		
		class_3966 hitResult = EntityUtils.createHitResult(clickTarget);
		class_1268 hand = class_1268.field_5808;
		class_1269 result =
			gm.method_2917(player, clickTarget, hitResult, hand);
		
		if(!result.method_23665())
			result = gm.method_2905(player, clickTarget, hand);
		
		if(result instanceof class_1269.class_9860 success
			&& success.comp_2909() == class_1269.class_9861.field_52427)
			player.method_6104(hand);
		
		clickTarget = null;
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(renderTarget == null)
			return;
		
		float p = 1;
		if(renderTarget.method_6063() > 1e-5)
			p = renderTarget.method_6032() / renderTarget.method_6063();
		float green = p * 2F;
		float red = 2 - green;
		float[] rgb = {red, green, 0};
		int quadColor = RenderUtils.toIntColor(rgb, 0.25F);
		int lineColor = RenderUtils.toIntColor(rgb, 0.5F);
		
		class_238 box = EntityUtils.getLerpedBox(renderTarget, partialTicks);
		if(p < 1)
			box = box.method_35580((1 - p) * 0.5 * box.method_17939(),
				(1 - p) * 0.5 * box.method_17940(), (1 - p) * 0.5 * box.method_17941());
		
		RenderUtils.drawSolidBox(matrixStack, box, quadColor, false);
		RenderUtils.drawOutlinedBox(matrixStack, box, lineColor, false);
	}
}
