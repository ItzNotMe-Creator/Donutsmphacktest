/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.freecam;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.util.text.WText;

public final class FreecamInitialPosSetting
	extends EnumSetting<FreecamInitialPosSetting.InitialPosition>
{
	private static final WText DESCRIPTION = buildDescription();
	
	public FreecamInitialPosSetting()
	{
		super("Initial position", DESCRIPTION, InitialPosition.values(),
			InitialPosition.INSIDE);
	}
	
	private static WText buildDescription()
	{
		WText text = WText
			.translated("description.wurst.setting.freecam.initial_position");
		
		for(InitialPosition value : InitialPosition.values())
			text = text
				.append(WText.literal("\n\n\u00a7l" + value.name + ":\u00a7r "))
				.append(value.description);
		
		return text;
	}
	
	public enum InitialPosition
	{
		INSIDE("Inside")
		{
			@Override
			public class_243 getPos(class_1297 cameraEntity)
			{
				return cameraEntity.method_33571();
			}
		},
		
		IN_FRONT("In Front")
		{
			@Override
			public class_243 getPos(class_1297 cameraEntity)
			{
				float yawRad = cameraEntity.method_5705(1) * class_3532.field_29847;
				double distance = 0.55;
				if(cameraEntity instanceof class_1309 le)
					distance *= le.method_55693();
				double offsetX = -class_3532.method_15374(yawRad) * distance;
				double offsetZ = class_3532.method_15362(yawRad) * distance;
				return cameraEntity.method_33571().method_1031(offsetX, 0, offsetZ);
			}
		},
		
		ABOVE("Above")
		{
			@Override
			public class_243 getPos(class_1297 cameraEntity)
			{
				double distance = 0.55;
				if(cameraEntity instanceof class_1309 le)
					distance *= le.method_55693();
				return cameraEntity.method_33571().method_1031(0, distance, 0);
			}
		};
		
		private static final String TRANSLATION_KEY_PREFIX =
			"description.wurst.setting.freecam.initial_position.";
		
		private final String name;
		private final WText description;
		
		private InitialPosition(String name)
		{
			this.name = name;
			description =
				WText.translated(TRANSLATION_KEY_PREFIX + name().toLowerCase());
		}
		
		public abstract class_243 getPos(class_1297 cameraEntity);
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
