/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.noclip.NoClipRenderer;
import net.wurstclient.hacks.noclip.NoClipRenderer.JumpToRender;
import net.wurstclient.mixinterface.IKeyMapping;
import net.wurstclient.settings.CheckboxSetting;

@SearchTags({"no clip"})
public final class NoClipHack extends Hack
	implements UpdateListener, RenderListener
{
	// Limited by ServerGamePacketListenerImpl.handleMovePlayer()
	public static final double MAX_DISTANCE_WITHOUT_ELYTRA = Math.sqrt(500);
	public static final double MAX_DISTANCE = Math.sqrt(1500);
	
	private final CheckboxSetting showPassableBlocks =
		new CheckboxSetting("Show passable blocks",
			"description.wurst.setting.noclip.show_passable_blocks", true);
	
	private final Set<JumpToRender> jumpsToRender = new LinkedHashSet<>();
	
	private class_243 direction = class_243.field_1353;
	private int preJumpTicks;
	private int postJumpTicks;
	private boolean needsButtonRelease;
	
	public NoClipHack()
	{
		super("NoClip");
		setCategory(Category.MOVEMENT);
		addSetting(showPassableBlocks);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		jumpsToRender.clear();
		direction = class_243.field_1353;
		preJumpTicks = 0;
		postJumpTicks = 0;
		needsButtonRelease = false;
	}
	
	@Override
	public void onUpdate()
	{
		jumpsToRender.clear();
		if(showPassableBlocks.isChecked()
			&& MC.field_1724.method_5745(64, 0, false) instanceof class_3965 hit)
			jumpsToRender
				.addAll(NoClipRenderer.findJumpsNear(hit.method_17777()));
		
		double forward = (MC.field_1690.field_1894.method_1434() ? 1 : 0)
			- (MC.field_1690.field_1881.method_1434() ? 1 : 0);
		double left = (MC.field_1690.field_1913.method_1434() ? 1 : 0)
			- (MC.field_1690.field_1849.method_1434() ? 1 : 0);
		double up = (MC.field_1690.field_1903.method_1434() ? 1 : 0)
			- (IKeyMapping.get(MC.field_1690.field_1832).isActuallyDown() ? 1 : 0);
		
		direction = new class_243(left, up, forward).method_1029()
			.method_1024(-MC.field_1724.method_36454() * class_3532.field_29847);
		if(direction.method_1027() == 0)
			needsButtonRelease = false;
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(showPassableBlocks.isChecked())
			NoClipRenderer.renderJumps(matrixStack, jumpsToRender);
	}
	
	public boolean shouldSendPosition()
	{
		if(!isEnabled())
			return true;
		
		if(postJumpTicks > 0)
		{
			postJumpTicks--;
			return false;
		}
		
		class_746 player = MC.field_1724;
		if(!player.method_5805() || player.method_7325() || MC.field_1755 != null
			|| WURST.getHax().freecamHack.isMovingCamera()
			|| MC.field_1687.method_52569(player,
				player.method_5829().method_1011(1e-5))
			|| needsButtonRelease || direction.method_1027() == 0)
		{
			preJumpTicks = 0;
			return true;
		}
		
		preJumpTicks++;
		if(preJumpTicks <= 2)
			return false;
		preJumpTicks = 0;
		
		needsButtonRelease = true;
		boolean canUseElytra = !player.method_6128() && !player.method_5799()
			&& !player.method_31549().field_7479
			&& !player.method_6059(class_1294.field_5902)
			&& class_1304.field_54086.stream().anyMatch(slot -> class_1309
				.method_63624(player.method_6118(slot), slot));
		
		class_243 destination = findDestination(direction, canUseElytra);
		if(destination == null)
			return true;
		
		class_2535 connection = player.field_3944.method_48296();
		for(int i = 0; i < 4; i++)
			connection.method_52906(
				new class_2828.class_5911(false, false), null,
				false);
		
		if(canUseElytra)
			connection.method_52906(
				new class_2848(player,
					class_2848.class_2849.field_12982),
				null, false);
			
		// Vanilla sends the final packet, flushes the batch and
		// remembers the position
		player.method_33574(destination);
		postJumpTicks = 2;
		return true;
	}
	
	private class_243 findDestination(class_243 direction, boolean canUseElytra)
	{
		double distance = 0;
		double maxDistance =
			canUseElytra ? MAX_DISTANCE : MAX_DISTANCE_WITHOUT_ELYTRA;
		
		while(distance < maxDistance)
		{
			distance = Math.min(distance + 0.25, maxDistance);
			class_243 offset = direction.method_1021(distance);
			class_238 box = MC.field_1724.method_5829().method_997(offset);
			
			if(!class_2338.method_29715(box.method_1011(1e-7))
				.allMatch(MC.field_1687::method_8477))
				return null;
				
			// noEntityCollision() only rejects entities with solid collision,
			// like boats. Normal entity collisions are allowed.
			if(MC.field_1687.method_52569(MC.field_1724, box)
				&& MC.field_1687.method_76792(MC.field_1724, box))
				return MC.field_1724.method_73189().method_1019(offset);
		}
		
		return null;
	}
}
