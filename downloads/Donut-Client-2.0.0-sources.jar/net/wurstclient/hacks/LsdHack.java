/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.wurstclient.Category;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;

@DontSaveState
public final class LsdHack extends Hack
{
	public static final class_2960 LSD_POST_EFFECT =
		class_2960.method_60655("wurst", "lsd");
	
	public LsdHack()
	{
		super("LSD");
		setCategory(Category.FUN);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().remoteViewHack.setEnabled(false);
		
		if(!(MC.method_1560() instanceof class_1657))
		{
			setEnabled(false);
			return;
		}
		
		if(MC.field_1773.method_62906() != null)
			MC.field_1773.method_62905();
		
		MC.field_1773.method_62904(LSD_POST_EFFECT);
	}
	
	@Override
	protected void onDisable()
	{
		if(MC.field_1773.method_62906() != null)
			MC.field_1773.method_62905();
	}
}
