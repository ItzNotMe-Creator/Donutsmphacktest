/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9362;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PlayerAttacksEntityListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"attribute swap", "weapon swap", "auto breach swap", "mace swap",
	"auto swap", "auto shield break", "auto mace", "disable shield",
	"item swap", "hotbar swap", "item saver", "durability saver"})
public final class AttributeSwapHack extends Hack
	implements PlayerAttacksEntityListener, UpdateListener
{
	private final EnumSetting<Mode> mode = new EnumSetting<>("Mode",
		"Simple: swaps to a fixed hotbar slot on attack.\n"
			+ "Smart: checks target and picks the best item automatically.",
		Mode.values(), Mode.SIMPLE);
	
	private final SliderSetting targetSlot = new SliderSetting("Target slot",
		"Hotbar slot to swap to (Simple mode).", 1, 1, 9, 1,
		ValueDisplay.INTEGER);
	
	private final CheckboxSetting swapBack = new CheckboxSetting("Swap back",
		"Swap back to the original slot after delay.", true);
	
	private final SliderSetting swapBackDelay =
		new SliderSetting("Swap-back delay",
			"How many ticks to wait before swapping back.", 2, 0, 20, 1,
			ValueDisplay.INTEGER.withSuffix(" ticks").withLabel(0, "instant"));
	
	private final CheckboxSetting breachSwapping = new CheckboxSetting(
		"Breach swapping",
		"Swaps to a mace with Breach to deal more damage (Smart mode).", true);
	
	private final CheckboxSetting shieldBreaker =
		new CheckboxSetting("Shield breaker",
			"Swaps to an axe when target is blocking (Smart mode).", true);
	
	private final CheckboxSetting itemSaver = new CheckboxSetting("Item saver",
		"Swaps to a non-damageable item to save main weapon durability (Smart mode).",
		true);
	
	private final CheckboxSetting onlyWithKillAura = new CheckboxSetting(
		"Only with Killaura", "Only activate when Killaura is enabled.", false);
	
	private int backTimer;
	private boolean awaitingBack;
	private int originalSlot;
	
	public AttributeSwapHack()
	{
		super("AttributeSwap");
		setCategory(Category.COMBAT);
		addSetting(mode);
		addSetting(targetSlot);
		addSetting(swapBack);
		addSetting(swapBackDelay);
		addSetting(shieldBreaker);
		addSetting(itemSaver);
		addSetting(breachSwapping);
		addSetting(onlyWithKillAura);
	}
	
	@Override
	protected void onEnable()
	{
		backTimer = 0;
		awaitingBack = false;
		originalSlot = -1;
		
		EVENTS.add(PlayerAttacksEntityListener.class, this);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PlayerAttacksEntityListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		
		if(awaitingBack)
		{
			doSwapBack();
			awaitingBack = false;
		}
		backTimer = 0;
		originalSlot = -1;
	}
	
	@Override
	public void onPlayerAttacksEntity(class_1297 target)
	{
		if(onlyWithKillAura.isChecked()
			&& !WURST.getHax().killauraHack.isEnabled())
			return;
		
		performSwap(target);
	}
	
	@Override
	public void onUpdate()
	{
		if(!awaitingBack)
			return;
		if(backTimer-- > 0)
			return;
		
		doSwapBack();
		awaitingBack = false;
	}
	
	private void performSwap(class_1297 target)
	{
		if(awaitingBack)
			return;
		
		if(mode.getSelected() == Mode.SIMPLE)
		{
			doSwap(targetSlot.getValueI() - 1);
			return;
		}
		
		doSwap(getSmartSlot(target));
	}
	
	private void doSwap(int slotIndex)
	{
		if(awaitingBack)
			return;
		if(slotIndex < 0 || slotIndex > 8)
			return;
		
		int current = MC.field_1724.method_31548().method_67532();
		if(slotIndex == current)
			return;
		
		originalSlot = current;
		MC.field_1724.method_31548().method_61496(slotIndex);
		
		if(swapBack.isChecked())
		{
			awaitingBack = true;
			backTimer = swapBackDelay.getValueI();
		}
	}
	
	private void doSwapBack()
	{
		if(originalSlot >= 0 && originalSlot <= 8)
			MC.field_1724.method_31548().method_61496(originalSlot);
		
		originalSlot = -1;
	}
	
	private int getSmartSlot(class_1297 target)
	{
		class_1799 current = MC.field_1724.method_6047();
		
		if(target instanceof class_1309 living && shieldBreaker.isChecked()
			&& living.method_6039())
		{
			if(current.method_7909() instanceof class_1743)
				return -1;
			
			int axeSlot =
				InventoryUtils.indexOf(s -> s.method_7909() instanceof class_1743, 9);
			if(axeSlot != -1)
				return axeSlot;
		}
		
		if(breachSwapping.isChecked() && target instanceof class_1309 le
			&& le.method_6127().method_26852(class_5134.field_23724) > 0)
		{
			int breachSlot =
				InventoryUtils.indexOf(s -> s.method_7909() instanceof class_9362
					&& getEnchantLevel(s, class_1893.field_50158) > 0, 9);
			
			if(breachSlot != -1)
				return breachSlot;
		}
		
		int bestSlot = -1;
		int bestScore = getDurabilityScore(current);
		
		for(int slot = 0; slot < 9; slot++)
		{
			if(slot == MC.field_1724.method_31548().method_67532())
				continue;
			
			class_1799 stack = MC.field_1724.method_31548().method_5438(slot);
			if(stack.method_7960())
				continue;
			
			int score = getDurabilityScore(stack);
			if(score > bestScore)
			{
				bestScore = score;
				bestSlot = slot;
			}
		}
		
		return bestSlot;
	}
	
	private int getDurabilityScore(class_1799 stack)
	{
		if(!itemSaver.isChecked())
			return 0;
		if(!stack.method_7963())
			return 4;
		
		return 0;
	}
	
	private int getEnchantLevel(class_1799 stack, class_5321<class_1887> key)
	{
		if(MC.field_1687 == null)
			return 0;
		
		return MC.field_1687.method_30349().method_46759(class_7924.field_41265)
			.flatMap(reg -> reg.method_46746(key)).map(holder -> class_1890
				.method_8225(holder, stack))
			.orElse(0);
	}
	
	private enum Mode
	{
		SIMPLE("Simple"),
		SMART("Smart");
		
		private final String name;
		
		private Mode(String name)
		{
			this.name = name;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
