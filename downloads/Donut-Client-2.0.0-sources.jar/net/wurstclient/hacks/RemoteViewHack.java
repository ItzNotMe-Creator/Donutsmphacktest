/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_8150;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.InteractFromSetting;
import net.wurstclient.settings.InteractFromSetting.InteractFrom;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.settings.filterlists.RemoteViewFilterList;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.EntityUtils;

@SearchTags({"remote view"})
@DontSaveState
public final class RemoteViewHack extends Hack implements UpdateListener
{
	private final InteractFromSetting interactFrom =
		new InteractFromSetting(this, InteractFrom.CAMERA);
	
	private final CheckboxSetting hideHand = new CheckboxSetting("Hide hand",
		"description.wurst.setting.remoteview.hide_hand", true);
	
	private final EntityFilterList entityFilters =
		RemoteViewFilterList.create();
	
	private class_1297 entity;
	
	public RemoteViewHack()
	{
		super("RemoteView");
		setCategory(Category.RENDER);
		addSetting(interactFrom);
		addSetting(hideHand);
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		// Find entity if not already set
		if(entity == null)
		{
			Stream<class_1297> stream = EntityUtils.getAliveEntities()
				.filter(
					e -> e instanceof class_1309 || e instanceof class_8150)
				.filter(EntityUtils.IS_NOT_SELF);
			
			stream = entityFilters.applyTo(stream);
			
			entity = stream
				.min(
					Comparator.comparingDouble(EntityUtils::distanceToHitboxSq))
				.orElse(null);
		}
		
		// Check if entity was found and is still valid
		if(!isEntityValid())
		{
			entity = null;
			ChatUtils.error("Could not find a valid entity.");
			setEnabled(false);
			return;
		}
		
		WURST.getHax().freecamHack.setEnabled(false);
		WURST.getHax().lsdHack.setEnabled(false);
		
		MC.method_1504(entity);
		ChatUtils.message("Now viewing " + entity.method_5477().getString() + ".");
		
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		
		if(entity == null)
			return;
		
		ChatUtils
			.message("No longer viewing " + entity.method_5477().getString() + ".");
		
		if(MC.method_1560() == entity)
			MC.method_1504(MC.field_1724);
		
		entity = null;
	}
	
	public void onToggledByCommand(String name)
	{
		if(name.isEmpty())
		{
			setEnabled(!isEnabled());
			return;
		}
		
		List<class_1297> matches = EntityUtils.getAliveEntities()
			.filter(e -> e instanceof class_1309 || e instanceof class_8150)
			.filter(EntityUtils.IS_NOT_SELF)
			.filter(e -> name.equalsIgnoreCase(e.method_5477().getString()))
			.sorted(Comparator.comparingDouble(EntityUtils::distanceToHitboxSq))
			.toList();
		
		if(matches.isEmpty())
		{
			ChatUtils.error("Entity \"" + name + "\" could not be found.");
			return;
		}
		
		class_1297 newEntity =
			matches.get((matches.indexOf(entity) + 1) % matches.size());
		
		if(isEnabled())
			setEnabled(false);
		
		entity = newEntity;
		setEnabled(true);
	}
	
	@Override
	public void onUpdate()
	{
		if(!isEntityValid() || MC.method_1560() != entity)
			setEnabled(false);
	}
	
	private boolean isEntityValid()
	{
		return entity != null && entity.method_5805() && MC.field_1687 != null
			&& MC.field_1687.method_66347(entity.method_5667()) != null;
	}
	
	public boolean isViewingEntity()
	{
		return isEnabled() && entity != null && MC.method_1560() == entity;
	}
	
	public boolean isClickingFromPlayer()
	{
		return isViewingEntity()
			&& interactFrom.getSelected() == InteractFrom.PLAYER;
	}
	
	public boolean shouldHideHand()
	{
		return isViewingEntity() && hideHand.isChecked();
	}
}
