/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.components;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_11909;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.Component;
import net.wurstclient.clickgui.screens.EditColorScreen;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.util.ColorUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.text.WText;

public final class ColorComponent extends Component
{
	private static final ClickGui GUI = WURST.getGui();
	private static final class_327 TR = MC.field_1772;
	private static final int TEXT_HEIGHT = 11;
	
	private final ColorSetting setting;
	
	public ColorComponent(ColorSetting setting)
	{
		this.setting = setting;
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void handleMouseClick(double mouseX, double mouseY, int mouseButton,
		class_11909 context)
	{
		if(mouseY < getY() + TEXT_HEIGHT)
			return;
		
		switch(mouseButton)
		{
			case GLFW.GLFW_MOUSE_BUTTON_LEFT:
			MC.method_1507(new EditColorScreen(MC.field_1755, setting));
			break;
			
			case GLFW.GLFW_MOUSE_BUTTON_RIGHT:
			setting.resetToDefault();
			break;
		}
	}
	
	@Override
	public void render(class_332 graphics, int mouseX, int mouseY,
		float partialTicks)
	{
		int x1 = getX();
		int x2 = x1 + getWidth();
		int y1 = getY();
		int y2 = y1 + getHeight();
		int y3 = y1 + TEXT_HEIGHT;
		
		boolean hovering = isHovering(mouseX, mouseY);
		boolean hText = hovering && mouseY < y3;
		boolean hColor = hovering && mouseY >= y3;
		
		if(hText)
			GUI.setTooltip(setting.getWrappedDescription(200));
		else if(hColor)
			GUI.setTooltip(getColorTooltip());
		
		// background
		float opacity = GUI.getOpacity();
		int bgColor = RenderUtils.toIntColor(GUI.getBgColor(), opacity);
		graphics.method_25294(x1, y1, x2, y3, bgColor);
		
		// box
		graphics.method_25294(x1, y3, x2, y2,
			setting.getColorI(hovering ? 1F : opacity));
		int outlineColor = RenderUtils.toIntColor(GUI.getAcColor(), 0.5F);
		RenderUtils.drawBorder2D(graphics, x1, y3, x2, y2, outlineColor);
		
		// text
		String name = setting.getName();
		String value = ColorUtils.toHex(setting.getColor());
		int valueWidth = TR.method_1727(value);
		int txtColor = GUI.getTxtColor();
		graphics.field_59826.method_71067();
		graphics.method_51433(TR, name, x1, y1 + 2, txtColor, false);
		graphics.method_51433(TR, value, x2 - valueWidth, y1 + 2, txtColor,
			false);
	}
	
	private String getColorTooltip()
	{
		return WText.literal("\u00a7cR:\u00a7r" + setting.getRed())
			.append(WText.literal(" \u00a7aG:\u00a7r" + setting.getGreen()))
			.append(WText.literal(" \u00a79B:\u00a7r" + setting.getBlue()))
			.append(WText.literal("\n\n"))
			.append(WText.translated("gui.wurst.generic.left_click_to_edit"))
			.append(WText.literal("\n"))
			.append(WText.translated("gui.wurst.generic.right_click_to_reset"))
			.toString();
	}
	
	@Override
	public int getDefaultWidth()
	{
		return TR.method_1727(setting.getName() + "#FFFFFF") + 6;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return TEXT_HEIGHT * 2;
	}
}
