/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.components;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.Component;
import net.wurstclient.clickgui.Window;
import net.wurstclient.clickgui.screens.EditBlockScreen;
import net.wurstclient.settings.BlockSetting;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.text.WText;

public final class BlockComponent extends Component
{
	private static final ClickGui GUI = WURST.getGui();
	private static final class_327 TR = MC.field_1772;
	private static final int BLOCK_WIDTH = 24;
	
	private final BlockSetting setting;
	
	public BlockComponent(BlockSetting setting)
	{
		this.setting = setting;
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void handleMouseClick(double mouseX, double mouseY, int mouseButton,
		class_11909 context)
	{
		if(mouseX < getX() + getWidth() - BLOCK_WIDTH)
			return;
		
		switch(mouseButton)
		{
			case GLFW.GLFW_MOUSE_BUTTON_LEFT:
			MC.method_1507(new EditBlockScreen(MC.field_1755, setting));
			break;
			
			case GLFW.GLFW_MOUSE_BUTTON_RIGHT:
			setting.resetToDefault();
			break;
		}
	}
	
	@Override
	public void render(class_332 graphics, int mouseX, int mouseY,
		float partialTicks)
	{
		int x1 = getX();
		int x2 = x1 + getWidth();
		int x3 = x2 - BLOCK_WIDTH;
		int y1 = getY();
		int y2 = y1 + getHeight();
		
		boolean hovering = isHovering(mouseX, mouseY, x1, y1, x2, y2);
		boolean hText = hovering && mouseX < x3;
		boolean hBlock = hovering && mouseX >= x3;
		
		// tooltip
		if(hText)
			GUI.setTooltip(setting.getWrappedDescription(200));
		else if(hBlock)
			GUI.setTooltip(getBlockTooltip());
		
		// background
		int bgColor =
			RenderUtils.toIntColor(GUI.getBgColor(), GUI.getOpacity());
		graphics.method_25294(x1, y1, x2, y2, bgColor);
		
		graphics.field_59826.method_71067();
		
		// text
		String name = setting.getName() + ":";
		graphics.method_51433(TR, name, x1, y1 + 2, GUI.getTxtColor(), false);
		
		// block
		class_1799 stack = new class_1799(setting.getBlock());
		RenderUtils.drawItem(graphics, stack, x3, y1, true);
	}
	
	private boolean isHovering(int mouseX, int mouseY, int x1, int y1, int x2,
		int y2)
	{
		Window parent = getParent();
		boolean scrollEnabled = parent.isScrollingEnabled();
		int scroll = scrollEnabled ? parent.getScrollOffset() : 0;
		
		return mouseX >= x1 && mouseY >= y1 && mouseX < x2 && mouseY < y2
			&& mouseY >= -scroll && mouseY < parent.getHeight() - 13 - scroll;
	}
	
	private String getBlockTooltip()
	{
		class_2248 block = setting.getBlock();
		class_2680 state = block.method_9564();
		class_1799 stack = new class_1799(block);
		
		String translatedName = stack.method_7960()
			? WText.translated("gui.wurst.generic.unknown_block").toString()
			: stack.method_7964().getString();
		String tooltip = "\u00a76Name:\u00a7r " + translatedName;
		
		String blockId = setting.getBlockName();
		tooltip += "\n\u00a76ID:\u00a7r " + blockId;
		
		int blockNumber = class_2248.method_9507(state);
		tooltip += "\n\u00a76Block #:\u00a7r " + blockNumber;
		
		tooltip +=
			"\n\n" + WText.translated("gui.wurst.generic.left_click_to_edit");
		tooltip +=
			"\n" + WText.translated("gui.wurst.generic.right_click_to_reset");
		
		return tooltip;
	}
	
	@Override
	public int getDefaultWidth()
	{
		return TR.method_1727(setting.getName() + ":") + BLOCK_WIDTH + 4;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return BLOCK_WIDTH;
	}
}
