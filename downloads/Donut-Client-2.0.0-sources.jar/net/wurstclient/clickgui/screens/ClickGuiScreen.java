/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.wurstclient.clickgui.ClickGui;

public final class ClickGuiScreen extends class_437
{
	private final ClickGui gui;
	
	public ClickGuiScreen(ClickGui gui)
	{
		super(class_2561.method_43470(""));
		this.gui = gui;
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25402(class_11909 context, boolean doubleClick)
	{
		gui.handleMouseClick(context);
		return super.method_25402(context, doubleClick);
	}
	
	@Override
	public boolean method_25406(class_11909 context)
	{
		gui.handleMouseRelease(context.comp_4798(), context.comp_4799(), context.method_74245());
		return super.method_25406(context);
	}
	
	@Override
	public boolean method_25401(double mouseX, double mouseY,
		double horizontalAmount, double verticalAmount)
	{
		gui.handleMouseScroll(mouseX, mouseY, verticalAmount);
		return super.method_25401(mouseX, mouseY, horizontalAmount,
			verticalAmount);
	}
	
	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY,
		float partialTicks)
	{
		for(class_4068 drawable : field_33816)
			drawable.method_25394(graphics, mouseX, mouseY, partialTicks);
		
		gui.render(graphics, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY,
		float deltaTicks)
	{
		// Don't blur
	}
}
