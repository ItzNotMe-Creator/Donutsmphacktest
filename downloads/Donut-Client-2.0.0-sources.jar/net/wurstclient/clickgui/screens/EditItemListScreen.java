/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.util.List;
import java.util.Objects;

import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import net.minecraft.class_8012;
import net.wurstclient.settings.ItemListSetting;
import net.wurstclient.util.ItemUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.WurstColors;

public final class EditItemListScreen extends class_437
{
	private final class_437 prevScreen;
	private final ItemListSetting itemList;
	
	private ListGui listGui;
	private class_342 itemNameField;
	private class_4185 addButton;
	private class_4185 removeButton;
	private class_4185 doneButton;
	
	private class_1792 itemToAdd;
	
	public EditItemListScreen(class_437 prevScreen, ItemListSetting itemList)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.itemList = itemList;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this, itemList.getItemNames());
		method_25429(listGui);
		
		itemNameField = new class_342(field_22787.field_1772, field_22789 / 2 - 152,
			field_22790 - 56, 150, 20, class_2561.method_43470(""));
		method_25429(itemNameField);
		itemNameField.method_1880(256);
		
		method_37063(
			addButton = class_4185.method_46430(class_2561.method_43470("Add"), b -> {
				itemList.add(itemToAdd);
				field_22787.method_1507(EditItemListScreen.this);
			}).method_46434(field_22789 / 2 - 2, field_22790 - 56, 30, 20).method_46431());
		
		method_37063(removeButton =
			class_4185.method_46430(class_2561.method_43470("Remove Selected"), b -> {
				itemList.remove(itemList.getItemNames()
					.indexOf(listGui.getSelectedBlockName()));
				field_22787.method_1507(EditItemListScreen.this);
			}).method_46434(field_22789 / 2 + 52, field_22790 - 56, 100, 20).method_46431());
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Reset to Defaults"),
				b -> field_22787.method_1507(new class_410(b2 -> {
					if(b2)
						itemList.resetToDefault();
					field_22787.method_1507(EditItemListScreen.this);
				}, class_2561.method_43470("Reset to Defaults"),
					class_2561.method_43470("Are you sure?"))))
				.method_46434(field_22789 - 108, 8, 100, 20).method_46431());
		
		method_37063(doneButton = class_4185
			.method_46430(class_2561.method_43470("Done"),
				b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 - 28, 200, 20).method_46431());
	}
	
	@Override
	public boolean method_25402(class_11909 context, boolean doubleClick)
	{
		itemNameField.method_25402(context, doubleClick);
		return super.method_25402(context, doubleClick);
	}
	
	@Override
	public boolean method_25404(class_11908 context)
	{
		switch(context.comp_4795())
		{
			case GLFW.GLFW_KEY_ENTER:
			if(addButton.field_22763)
				addButton.method_25306(context);
			break;
			
			case GLFW.GLFW_KEY_DELETE:
			if(!itemNameField.method_25370())
				removeButton.method_25306(context);
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			doneButton.method_25306(context);
			break;
			
			default:
			break;
		}
		
		return super.method_25404(context);
	}
	
	@Override
	public void method_25393()
	{
		String nameOrId = itemNameField.method_1882().toLowerCase();
		itemToAdd = ItemUtils.getItemFromNameOrID(nameOrId);
		addButton.field_22763 = itemToAdd != null;
		
		removeButton.field_22763 = listGui.method_25334() != null;
	}
	
	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY,
		float partialTicks)
	{
		Matrix3x2fStack matrixStack = graphics.method_51448();
		
		listGui.method_25394(graphics, mouseX, mouseY, partialTicks);
		
		graphics.method_25300(field_22787.field_1772,
			itemList.getName() + " (" + itemList.getItemNames().size() + ")",
			field_22789 / 2, 12, class_8012.field_42973);
		
		matrixStack.pushMatrix();
		
		itemNameField.method_25394(graphics, mouseX, mouseY, partialTicks);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(graphics, mouseX, mouseY, partialTicks);
		
		graphics.field_59826.method_71067();
		matrixStack.pushMatrix();
		matrixStack.translate(-64 + field_22789 / 2 - 152, 0);
		
		if(itemNameField.method_1882().isEmpty() && !itemNameField.method_25370())
			graphics.method_25303(field_22787.field_1772, "item name or ID", 68,
				field_22790 - 50, class_8012.field_44941);
		
		int border = itemNameField.method_25370() ? class_8012.field_42973
			: class_8012.field_45073;
		int black = class_8012.field_42974;
		
		graphics.method_25294(48, field_22790 - 56, 64, field_22790 - 36, border);
		graphics.method_25294(49, field_22790 - 55, 65, field_22790 - 37, black);
		graphics.method_25294(214, field_22790 - 56, 244, field_22790 - 55, border);
		graphics.method_25294(214, field_22790 - 37, 244, field_22790 - 36, border);
		graphics.method_25294(244, field_22790 - 56, 246, field_22790 - 36, border);
		graphics.method_25294(213, field_22790 - 55, 243, field_22790 - 52, black);
		graphics.method_25294(213, field_22790 - 40, 243, field_22790 - 37, black);
		graphics.method_25294(213, field_22790 - 55, 216, field_22790 - 37, black);
		graphics.method_25294(242, field_22790 - 55, 245, field_22790 - 37, black);
		
		matrixStack.popMatrix();
		
		RenderUtils.drawItem(graphics,
			itemToAdd == null ? class_1799.field_8037 : new class_1799(itemToAdd),
			field_22789 / 2 - 164, field_22790 - 52, false);
		
		matrixStack.popMatrix();
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<EditItemListScreen.Entry>
	{
		private final String itemName;
		
		public Entry(String itemName)
		{
			this.itemName = Objects.requireNonNull(itemName);
		}
		
		@Override
		public class_2561 method_37006()
		{
			class_1792 item =
				class_7923.field_41178.method_63535(class_2960.method_60654(itemName));
			class_1799 stack = new class_1799(item);
			
			return class_2561.method_43469("narrator.select",
				"Item " + getDisplayName(stack) + ", " + itemName + ", "
					+ getIdText(item));
		}
		
		@Override
		public void method_25343(class_332 graphics, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			int x = method_73380();
			int y = method_73382();
			
			class_1792 item =
				class_7923.field_41178.method_63535(class_2960.method_60654(itemName));
			class_1799 stack = new class_1799(item);
			class_327 tr = field_22787.field_1772;
			
			RenderUtils.drawItem(graphics, stack, x + 1, y + 1, true);
			graphics.method_51433(tr, getDisplayName(stack), x + 28, y,
				WurstColors.VERY_LIGHT_GRAY, false);
			graphics.method_51433(tr, itemName, x + 28, y + 9,
				class_8012.field_45073, false);
			graphics.method_51433(tr, getIdText(item), x + 28, y + 18,
				class_8012.field_45073, false);
		}
		
		private String getDisplayName(class_1799 stack)
		{
			return stack.method_7960() ? "\u00a7ounknown item\u00a7r"
				: stack.method_7964().getString();
		}
		
		private String getIdText(class_1792 item)
		{
			return "ID: " + class_7923.field_41178.method_10206(item);
		}
	}
	
	private final class ListGui
		extends class_4280<EditItemListScreen.Entry>
	{
		public ListGui(class_310 minecraft, EditItemListScreen screen,
			List<String> list)
		{
			super(minecraft, screen.field_22789, screen.field_22790 - 96, 36, 30);
			
			list.stream().map(EditItemListScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		public String getSelectedBlockName()
		{
			EditItemListScreen.Entry selected = method_25334();
			return selected != null ? selected.itemName : null;
		}
	}
}
