/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import net.minecraft.class_310;
import net.minecraft.class_744;
import net.minecraft.class_746;
import net.wurstclient.events.UpdateListener;

/**
 * Temporarily replaces the player's input with an empty {@link class_744} to
 * prevent the player from controlling their character or vehicle. Currently
 * only used by Freecam in Camera mode. If any other hacks need this
 * functionality in the future, this file should be updated accordingly.
 *
 * <p>
 * Use {@link TempRealInput} (try-with-resources) to temporarily restore the
 * real input when needed. {@link UpdateListener#onUpdate()} events already have
 * it restored automatically.
 */
public enum InputFaker
{
	;
	
	private static final class_310 MC = WurstClient.MC;
	
	private static class_744 realInput;
	private static int swapDepth;
	
	public static void swapIfNeeded()
	{
		if(!WurstClient.INSTANCE.getHax().freecamHack.isMovingCamera())
			return;
		
		swapDepth++;
		if(swapDepth > 1)
			return;
		
		class_746 player = MC.field_1724;
		realInput = player.field_3913;
		player.field_3913.method_3129();
		player.field_3913 = new class_744();
	}
	
	public static void restoreIfNeeded()
	{
		if(swapDepth > 0)
			swapDepth--;
		
		if(swapDepth > 0 || realInput == null)
			return;
		
		MC.field_1724.field_3913 = realInput;
		realInput = null;
	}
	
	/**
	 * An {@link AutoCloseable} scope that temporarily restores the real
	 * input when needed. {@link UpdateListener#onUpdate()} events already have
	 * it restored automatically.
	 *
	 * <p>
	 * Usage: try(TempRealInput ignore = new TempRealInput()) { ... }
	 */
	public static class TempRealInput implements AutoCloseable
	{
		public TempRealInput()
		{
			if(realInput != null)
				MC.field_1724.field_3913 = realInput;
		}
		
		@Override
		public void close()
		{
			if(realInput != null)
				MC.field_1724.field_3913 = new class_744();
		}
	}
}
