/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import net.minecraft.class_243;
import net.minecraft.class_746;
import net.wurstclient.util.Rotation;
import net.wurstclient.util.RotationUtils;

public final class RotationFaker
{
	private boolean shouldFakeRotation;
	private boolean didFakeRotation;
	private float serverYaw;
	private float serverPitch;
	private float realYaw;
	private float realPitch;
	
	public void applyIfNeeded()
	{
		if(!shouldFakeRotation || !WurstClient.INSTANCE.isEnabled())
			return;
		
		class_746 player = WurstClient.MC.field_1724;
		realYaw = player.method_36454();
		realPitch = player.method_36455();
		player.method_36456(serverYaw);
		player.method_36457(serverPitch);
		didFakeRotation = true;
	}
	
	public void restoreIfNeeded()
	{
		if(!didFakeRotation)
			return;
		
		class_746 player = WurstClient.MC.field_1724;
		player.method_36456(realYaw);
		player.method_36457(realPitch);
		shouldFakeRotation = false;
		didFakeRotation = false;
	}
	
	public void faceVectorPacket(class_243 vec)
	{
		Rotation needed = RotationUtils.getNeededRotations(vec);
		class_746 player = WurstClient.MC.field_1724;
		
		shouldFakeRotation = true;
		serverYaw =
			RotationUtils.limitAngleChange(player.method_36454(), needed.yaw());
		serverPitch = needed.pitch();
	}
	
	public void faceVectorClient(class_243 vec)
	{
		Rotation needed = RotationUtils.getNeededRotations(vec);
		
		class_746 player = WurstClient.MC.field_1724;
		player.method_36456(
			RotationUtils.limitAngleChange(player.method_36454(), needed.yaw()));
		player.method_36457(needed.pitch());
	}
	
	public void faceVectorClientIgnorePitch(class_243 vec)
	{
		Rotation needed = RotationUtils.getNeededRotations(vec);
		
		class_746 player = WurstClient.MC.field_1724;
		player.method_36456(
			RotationUtils.limitAngleChange(player.method_36454(), needed.yaw()));
		player.method_36457(0);
	}
	
	public float getServerYaw()
	{
		return shouldFakeRotation ? serverYaw : WurstClient.MC.field_1724.method_36454();
	}
	
	public float getServerPitch()
	{
		return shouldFakeRotation ? serverPitch
			: WurstClient.MC.field_1724.method_36455();
	}
}
