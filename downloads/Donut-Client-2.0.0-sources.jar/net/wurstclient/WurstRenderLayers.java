/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;

public enum WurstRenderLayers
{
	;
	
	/**
	 * Similar to {@link class_1921#getLines()}, but with line width 2.
	 */
	public static final class_1921 LINES = class_1921.method_75940("wurst:lines",
		class_12247.method_75927(WurstShaderPipelines.DEPTH_TEST_LINES)
			.method_75930(class_12245.field_63976)
			.method_75931(class_12246.field_63983)
			.method_75938());
	
	/**
	 * Similar to {@link class_1921#getLines()}, but with line width 2 and no
	 * depth test.
	 */
	public static final class_1921 ESP_LINES =
		class_1921.method_75940("wurst:esp_lines",
			class_12247.method_75927(WurstShaderPipelines.ESP_LINES)
				.method_75930(class_12245.field_63976)
				.method_75931(class_12246.field_63983)
				.method_75938());
	
	/**
	 * Similar to {@link class_1921#getDebugQuads()}, but with culling enabled.
	 */
	public static final class_1921 QUADS = class_1921.method_75940("wurst:quads",
		class_12247.method_75927(WurstShaderPipelines.QUADS).method_75937()
			.method_75938());
	
	/**
	 * Similar to {@link class_1921#getDebugQuads()}, but with culling enabled
	 * and no depth test.
	 */
	public static final class_1921 ESP_QUADS = class_1921.method_75940(
		"wurst:esp_quads", class_12247.method_75927(WurstShaderPipelines.ESP_QUADS)
			.method_75937().method_75938());
	
	/**
	 * Similar to {@link class_1921#getDebugQuads()}, but with no depth test.
	 */
	public static final class_1921 ESP_QUADS_NO_CULLING =
		class_1921.method_75940("wurst:esp_quads_no_culling",
			class_12247.method_75927(WurstShaderPipelines.ESP_QUADS_NO_CULLING)
				.method_75937().method_75928().method_75938());
	
	/**
	 * Returns either {@link #QUADS} or {@link #ESP_QUADS} depending on the
	 * value of {@code depthTest}.
	 */
	public static class_1921 getQuads(boolean depthTest)
	{
		return depthTest ? QUADS : ESP_QUADS;
	}
	
	/**
	 * Returns either {@link #LINES} or {@link #ESP_LINES} depending on the
	 * value of {@code depthTest}.
	 */
	public static class_1921 getLines(boolean depthTest)
	{
		return depthTest ? LINES : ESP_LINES;
	}
}
